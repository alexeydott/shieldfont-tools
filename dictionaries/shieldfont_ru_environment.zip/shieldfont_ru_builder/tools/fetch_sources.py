#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from io_utils import load_json, package_root, sha256

USER_AGENT = 'shieldfont-ru-reproducible-builder/1.0'


def download(url: str, destination: Path, expected_sha256: str, retries: int = 4) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(destination.suffix + '.part')
    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
            with urllib.request.urlopen(request, timeout=120) as response, temp.open('wb') as output:
                shutil.copyfileobj(response, output, length=1024 * 1024)
            actual = sha256(temp)
            if actual != expected_sha256:
                raise RuntimeError(f'checksum mismatch: {actual} != {expected_sha256}')
            temp.replace(destination)
            return
        except Exception as exc:
            last_error = exc
            temp.unlink(missing_ok=True)
            if attempt < retries:
                time.sleep(2 ** (attempt - 1))
    raise RuntimeError(f'failed to download {url}: {last_error}')


def main() -> int:
    parser = argparse.ArgumentParser(description='Download exact locked public data files and copy russian.dic input.')
    parser.add_argument('--data-dir', type=Path, default=package_root() / 'data')
    parser.add_argument('--dictionary', type=Path, required=True, help='Path to the original russian.dic ZIP.')
    parser.add_argument('--lock', type=Path, default=package_root() / 'config' / 'sources.lock.json')
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args()

    lock = load_json(args.lock)
    args.data_dir.mkdir(parents=True, exist_ok=True)
    dictionary_item = next(item for item in lock['files'] if item.get('manual'))
    if not args.dictionary.is_file():
        print(f'Dictionary file not found: {args.dictionary}', file=sys.stderr)
        return 2
    actual_dictionary_hash = sha256(args.dictionary)
    if actual_dictionary_hash != dictionary_item['sha256']:
        print('The supplied dictionary is not the exact dictionary used for the original build.', file=sys.stderr)
        print(f'actual:   {actual_dictionary_hash}', file=sys.stderr)
        print(f'expected: {dictionary_item["sha256"]}', file=sys.stderr)
        return 2
    dictionary_target = args.data_dir / dictionary_item['path']
    dictionary_target.parent.mkdir(parents=True, exist_ok=True)
    if args.dictionary.resolve() != dictionary_target.resolve():
        shutil.copy2(args.dictionary, dictionary_target)
    print(f'PASS     {dictionary_item["path"]}')

    for item in lock['files']:
        if item.get('manual'):
            continue
        target = args.data_dir / item['path']
        if target.is_file() and not args.force and sha256(target) == item['sha256']:
            print(f'CACHED   {item["path"]}')
            continue
        print(f'DOWNLOAD {item["path"]}')
        try:
            download(item['url'], target, item['sha256'])
        except Exception as exc:
            print(str(exc), file=sys.stderr)
            return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
