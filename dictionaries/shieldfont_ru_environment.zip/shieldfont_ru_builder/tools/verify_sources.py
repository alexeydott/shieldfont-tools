#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from io_utils import load_json, package_root, sha256


def main() -> int:
    parser = argparse.ArgumentParser(description='Verify all locked source files.')
    parser.add_argument('--data-dir', type=Path, default=package_root() / 'data')
    parser.add_argument('--lock', type=Path, default=package_root() / 'config' / 'sources.lock.json')
    args = parser.parse_args()

    lock = load_json(args.lock)
    failed = False
    for item in lock['files']:
        path = args.data_dir / item['path']
        if not path.is_file():
            print(f'MISSING  {item["path"]}')
            failed = True
            continue
        size = path.stat().st_size
        actual = sha256(path)
        errors = []
        if size != item['bytes']:
            errors.append(f'bytes={size}, expected={item["bytes"]}')
        if actual != item['sha256']:
            errors.append(f'sha256={actual}, expected={item["sha256"]}')
        if errors:
            print(f'FAIL     {item["path"]}: ' + '; '.join(errors))
            failed = True
        else:
            print(f'PASS     {item["path"]}')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
