#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

CYR = re.compile(r'^[а-яё]+$')
EXPECTED = {'alpha': 11970, 'beta': 12034, 'gamma': 12036, 'omega': 2534}


def main() -> int:
    parser = argparse.ArgumentParser(description='Validate mapping counts, Unicode safety and involution.')
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parents[1] / 'out')
    args = parser.parse_args()
    failed = False
    for name, count in EXPECTED.items():
        path = args.output_dir / 'mappings' / f'{name}.json'
        if not path.is_file():
            print(name, 'FAIL', f'missing {path}')
            failed = True
            continue
        mapping = json.loads(path.read_text(encoding='utf-8'))
        errors: list[str] = []
        if len(mapping) != count:
            errors.append(f'count={len(mapping)}, expected={count}')
        for source, target in mapping.items():
            if source == target:
                errors.append(f'identity {source}')
            if mapping.get(target) != source:
                errors.append(f'non-involution {source}->{target}->{mapping.get(target)}')
            for word in (source, target):
                if word != unicodedata.normalize('NFC', word) or word != word.lower() or not CYR.fullmatch(word):
                    errors.append(f'unsafe {word!r}')
            if errors:
                break
        print(name, 'PASS' if not errors else 'FAIL', '; '.join(errors))
        failed |= bool(errors)
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
