#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from io_utils import load_json, package_root, sha256


def main() -> int:
    parser = argparse.ArgumentParser(description='Verify generated files against original build hashes.')
    parser.add_argument('--output-dir', type=Path, default=package_root() / 'out')
    parser.add_argument('--expected', type=Path, default=package_root() / 'config' / 'expected_outputs.json')
    args = parser.parse_args()

    expected = load_json(args.expected)['files']
    failed = False
    for relative, info in expected.items():
        path = args.output_dir / relative
        if not path.is_file():
            print(f'MISSING  {relative}')
            failed = True
            continue
        actual = sha256(path)
        if actual != info['sha256'] or path.stat().st_size != info['bytes']:
            print(f'FAIL     {relative}: sha256={actual}, bytes={path.stat().st_size}')
            failed = True
        else:
            print(f'PASS     {relative}')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
