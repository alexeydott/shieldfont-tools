from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import random
import re
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
import shutil
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from rapidfuzz.fuzz import ratio

ROOT = Path.cwd() / 'data'
OUT = Path.cwd() / 'out'

CYR = re.compile(r'^[а-яё]+$')
EN_WORD = re.compile(r"[a-z]+")

TARGETS = {
    'alpha': 5985,
    'beta': 6017,
    'gamma': 6018,
    'omega': 1267,
}
SEEDS = {'alpha': 42, 'beta': 1, 'gamma': 2, 'omega': 314159}

# Function-like or pronominal lemmas that can be listed as adjectives/nouns in lexicons.
RU_FUNCTION_EXCLUDE = {
    'этот','тот','который','какой','такой','весь','всякий','каждый','любой','иной','другой',
    'сам','самый','свой','мой','твой','наш','ваш','его','её','ее','их','данный','некоторый',
    'один','два','три','четыре','пять','шесть','семь','восемь','девять','десять',
    'многий','несколько','столько','сколько','чей','никакой','какой-то','кто','что',
    'российский','русский','советский','московский','американский',  # proper/geopolitical bias
}

EN_STOP = {
    'a','an','the','to','of','in','on','at','by','for','from','with','without','and','or','but',
    'be','is','are','was','were','been','being','do','does','did','done','have','has','had',
    'one','ones','someone','something','somebody','some','any','it','its','this','that','these','those',
    'as','into','onto','upon','about','over','under','through','out','up','down','off','not','no',
    'person','thing','things','etc','usually','especially','also','used','use','make','get','go',
    'someone','somebody','oneself','himself','herself','itself','themself','themselves',
}

# Coarse semantic classes are used only as a veto/bonus. Unknown is allowed.
SEM_CLASSES = {
    'person': {'person','man','woman','child','boy','girl','people','worker','teacher','doctor','soldier','friend','father','mother','son','daughter','husband','wife','citizen','member','guest','hero','director','author'},
    'body': {'body','head','hand','arm','leg','foot','eye','face','heart','blood','finger','shoulder','mouth','skin','brain','hair','bone','voice'},
    'place': {'place','city','town','village','country','state','region','district','street','room','house','home','building','road','way','area','territory','border','center','school','office','market','store'},
    'nature': {'water','air','earth','ground','land','sea','river','forest','tree','mountain','sun','sky','fire','animal','dog','plant','weather','nature'},
    'time': {'time','year','day','night','morning','evening','hour','minute','month','week','period','moment','age','century','beginning','end'},
    'artefact': {'book','machine','car','computer','phone','document','letter','table','door','window','film','picture','music','song','money','product','material','weapon','clothes','food'},
    'social': {'government','power','law','war','army','society','company','organization','party','business','economy','politics','culture','science','education','system','service','work','job'},
    'abstract': {'idea','thought','meaning','reason','cause','result','problem','question','answer','decision','information','knowledge','truth','quality','condition','situation','possibility','freedom','choice','goal','method','rule','principle'},
    'emotion': {'love','fear','hope','desire','feeling','joy','sadness','anger','pain','happiness','pleasure','worry','interest'},
    'motion': {'go','walk','run','come','leave','enter','exit','move','travel','drive','fly','carry','bring','return','fall','stand','sit','lie'},
    'communication': {'say','tell','speak','talk','write','read','ask','answer','call','show','name','report','message','listen','hear'},
    'cognition': {'know','think','understand','remember','forget','believe','consider','decide','learn','notice','see','look','feel','want'},
    'change': {'create','destroy','build','open','close','start','finish','change','develop','grow','reduce','increase','produce','make','become','remain','happen'},
    'quantity': {'number','amount','part','half','group','pair','level','size','price','value','degree','measure','many','few','large','small'},
    'property': {'good','bad','big','small','new','old','high','low','long','short','strong','weak','important','main','common','special','real','possible','free','beautiful'},
}

POS_ALLOWED = {'N', 'V', 'ADJ'}
TAG_ALLOWED_PREFIX = {
    'N': ('N;',),
    'V': ('V;',),  # deliberately exclude participles and converbs
    'ADJ': ('ADJ;',),
}


def nfc_lower(s: str) -> str:
    return unicodedata.normalize('NFC', s.strip().lower()).replace("'", '').replace('’', '')


def clean_en_tokens(text: str) -> tuple[str, ...]:
    toks = []
    for t in EN_WORD.findall(text.lower()):
        if len(t) < 3 or t in EN_STOP:
            continue
        # lightweight suffix normalization, sufficient for overlap vetoes
        for suf in ('ingly','edly','ation','ments','ment','ness','ities','ity','ing','ed','es','s'):
            if t.endswith(suf) and len(t) - len(suf) >= 3:
                t = t[:-len(suf)]
                break
        toks.append(t)
    return tuple(sorted(set(toks)))


def semantic_classes(tokens: Iterable[str]) -> frozenset[str]:
    ts = set(tokens)
    return frozenset(k for k, words in SEM_CLASSES.items() if ts & words)


def common_prefix_len(a: str, b: str) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def common_suffix_len(a: str, b: str) -> int:
    return common_prefix_len(a[::-1], b[::-1])


def lemma_related(a: str, b: str) -> bool:
    if a == b:
        return True
    short = min(len(a), len(b))
    if short <= 0:
        return True
    sim = ratio(a, b) / 100.0
    if sim >= 0.58:
        return True
    if short >= 5 and common_prefix_len(a, b) / short >= 0.65:
        return True
    if short >= 6 and common_suffix_len(a, b) / short >= 0.70:
        return True
    return False


@dataclass
class Meta:
    pos: str
    translation: str
    tokens: tuple[str, ...]
    classes: frozenset[str]
    gender: str = ''
    animate: str = ''
    indeclinable: str = ''
    aspect: str = ''
    reflexive: bool = False
    valency: tuple[str, ...] = ()
    corpus_valency: tuple[str, ...] = ()
    corpus_occurrences: int = 0
    ru_synsets: frozenset[str] = frozenset()
    wn_synsets: frozenset[tuple[str, str]] = frozenset()
    wn_near: frozenset[tuple[str, str]] = frozenset()
    wn_categories: frozenset[str] = frozenset()


@dataclass
class LemmaRecord:
    lemma: str
    meta: Meta
    rank: int
    forms: dict[tuple, str] = field(default_factory=dict)
    form_rank: dict[tuple, int] = field(default_factory=dict)

    @property
    def coarse_key(self) -> tuple:
        if self.meta.pos == 'N':
            return ('N', self.meta.gender, self.meta.animate, self.meta.indeclinable)
        if self.meta.pos == 'V':
            return ('V', self.meta.aspect, self.meta.reflexive, self.meta.valency, self.meta.corpus_valency)
        return ('ADJ',)


@dataclass(frozen=True)
class PairRow:
    source: str
    target: str
    source_lemma: str
    target_lemma: str
    pos: str
    signature: tuple
    grammar_class: tuple
    source_rank: int
    target_rank: int
    source_translation: str
    target_translation: str
    semantic_token_overlap: int
    source_classes: tuple[str, ...]
    target_classes: tuple[str, ...]
    curated: bool = False


def load_whitelist() -> set[str]:
    archive = ROOT / 'russian.dic(1).zip'
    with zipfile.ZipFile(archive) as zf:
        names = zf.namelist()
        if len(names) != 1:
            raise RuntimeError(f'Expected exactly one archive member, got {names!r}')
        lines = zf.read(names[0]).decode('utf-8').splitlines()
    # Lowercase-only requirement excludes entries present only as proper names/abbreviations.
    return {
        nfc_lower(x) for x in lines
        if x == x.lower() and CYR.fullmatch(nfc_lower(x))
    }


def load_frequency() -> tuple[dict[str, int], list[str]]:
    """Merge Leeds frequency order with forms attested at least twice in SynTagRus."""
    rank: dict[str, int] = {}
    ordered: list[str] = []
    with open(ROOT / 'russian_frequency_50000.txt', encoding='utf-8') as f:
        for line in f:
            word = nfc_lower(line)
            if not CYR.fullmatch(word) or word in rank:
                continue
            rank[word] = len(rank) + 1
            ordered.append(word)

    corpus_counts: Counter[str] = Counter()
    for path in sorted(ROOT.glob('ru_syntagrus-ud-train-*.conllu')):
        with open(path, encoding='utf-8') as f:
            for line in f:
                if line.startswith('#') or not line.strip():
                    continue
                cols = line.rstrip('\n').split('\t')
                if len(cols) != 10 or not cols[0].isdigit():
                    continue
                word = nfc_lower(cols[1])
                if CYR.fullmatch(word):
                    corpus_counts[word] += 1
    for word, _count in sorted(corpus_counts.items(), key=lambda item: (-item[1], item[0])):
        if corpus_counts[word] < 2 or word in rank:
            continue
        rank[word] = len(rank) + 1
        ordered.append(word)
    return rank, ordered


def load_apertium_valency() -> dict[str, tuple[str, ...]]:
    """Extract coarse transitivity classes from Apertium lemma entries.

    Multiple readings are retained as a sorted set; pairing later requires exact set equality.
    """
    result: dict[str, set[str]] = defaultdict(set)
    superscripts = {ord(c): None for c in '¹²³⁴⁵⁶⁷⁸⁹⁰'}
    rx = re.compile(r'<e\s+lm="([^"]+)"[^>]*>.*?<par\s+n="([^"]+)"')
    with open(ROOT / 'apertium-rus.rus.dix', encoding='utf-8') as f:
        for line in f:
            m = rx.search(line)
            if not m:
                continue
            lemma = nfc_lower(html.unescape(m.group(1)).translate(superscripts))
            paradigm = html.unescape(m.group(2)).lower()
            if not any(x in paradigm for x in ('vblex', 'vbmod', 'vbser', 'vbhaver')):
                continue
            if '_tv' in paradigm or '.tv' in paradigm:
                result[lemma].add('tv')
            if '_iv' in paradigm or '.iv' in paradigm:
                result[lemma].add('iv')
    return {lemma: tuple(sorted(values)) for lemma, values in result.items() if values}


def parse_ud_feats(value: str) -> dict[str, str]:
    if value == '_':
        return {}
    return dict(item.split('=', 1) for item in value.split('|') if '=' in item)


def load_syntagrus_valency() -> dict[str, tuple[tuple[str, ...], int]]:
    """Build conservative corpus-derived government profiles for Russian verbs.

    Profiles are based on three human-corrected SynTagRus training partitions.
    Only lemmas observed at least five times are retained. The profile captures
    object frequency/case, indirect-object frequency/case, clausal complements,
    and one strongly recurrent preposition+case oblique construction.
    """
    stats: dict[str, dict] = defaultdict(
        lambda: {'n': 0, 'obj': Counter(), 'iobj': Counter(), 'clause': Counter(), 'obl': Counter()}
    )

    def process_sentence(sentence: list[list[str]]) -> None:
        if not sentence:
            return
        tokens = {int(cols[0]): cols for cols in sentence if cols[0].isdigit()}
        children: dict[int, list[list[str]]] = defaultdict(list)
        for cols in tokens.values():
            try:
                children[int(cols[6])].append(cols)
            except ValueError:
                continue

        for idx, cols in tokens.items():
            if cols[3] != 'VERB':
                continue
            lemma = nfc_lower(cols[2])
            if not CYR.fullmatch(lemma):
                continue
            entry = stats[lemma]
            entry['n'] += 1
            for child in children.get(idx, []):
                relation = child[7].split(':', 1)[0]
                case = parse_ud_feats(child[5]).get('Case', '?')
                if relation == 'obj':
                    entry['obj'][case] += 1
                elif relation == 'iobj':
                    entry['iobj'][case] += 1
                elif relation in {'ccomp', 'xcomp', 'csubj'}:
                    entry['clause'][relation] += 1
                elif relation == 'obl':
                    try:
                        child_id = int(child[0])
                    except ValueError:
                        continue
                    prepositions = {
                        nfc_lower(grandchild[2])
                        for grandchild in children.get(child_id, [])
                        if grandchild[7].split(':', 1)[0] == 'case' and grandchild[3] == 'ADP'
                    }
                    for prep in prepositions:
                        if CYR.fullmatch(prep):
                            entry['obl'][f'{prep}:{case}'] += 1

    for path in sorted(ROOT.glob('ru_syntagrus-ud-train-*.conllu')):
        sentence: list[list[str]] = []
        with open(path, encoding='utf-8') as f:
            for line in f:
                line = line.rstrip('\n')
                if not line:
                    process_sentence(sentence)
                    sentence = []
                    continue
                if line.startswith('#'):
                    continue
                cols = line.split('\t')
                if len(cols) == 10 and '-' not in cols[0] and '.' not in cols[0]:
                    sentence.append(cols)
            process_sentence(sentence)

    def argument_class(counter: Counter, occurrences: int, low: float, high: float) -> tuple[str, str]:
        total = sum(counter.values())
        ratio_value = total / occurrences if occurrences else 0.0
        cls = 'none' if ratio_value < low else ('optional' if ratio_value < high else 'common')
        dominant_case = ''
        if cls != 'none' and total:
            case, count = counter.most_common(1)[0]
            if count / total >= 0.55:
                dominant_case = case
        return cls, dominant_case

    profiles: dict[str, tuple[tuple[str, ...], int]] = {}
    for lemma, entry in stats.items():
        n = entry['n']
        if n < 5:
            continue
        obj_class, obj_case = argument_class(entry['obj'], n, 0.08, 0.35)
        iobj_class, iobj_case = argument_class(entry['iobj'], n, 0.04, 0.20)
        clause_class, _ = argument_class(entry['clause'], n, 0.04, 0.20)
        core_oblique = ''
        if entry['obl']:
            construction, count = entry['obl'].most_common(1)[0]
            if count >= 3 and count / n >= 0.18:
                core_oblique = construction
        profile = (
            f'obj:{obj_class}:{obj_case}',
            f'iobj:{iobj_class}:{iobj_case}',
            f'clause:{clause_class}',
            f'obl:{core_oblique}',
        )
        profiles[lemma] = (profile, n)
    return profiles


def load_ruwordnet_synsets() -> dict[str, frozenset[str]]:
    """Map single-word Russian lemmas to RuWordNet synsets for synonym vetoes."""
    result: dict[str, set[str]] = defaultdict(set)
    for pos in ('N', 'A', 'V'):
        path = ROOT / f'ruwordnet_senses.{pos}.xml'
        for _event, elem in ET.iterparse(path, events=('end',)):
            if elem.tag != 'sense':
                continue
            name = nfc_lower(elem.attrib.get('name', ''))
            synset_id = elem.attrib.get('synset_id', '')
            if CYR.fullmatch(name) and synset_id:
                result[name].add(synset_id)
            elem.clear()
    return {lemma: frozenset(ids) for lemma, ids in result.items()}


def load_english_wordnet() -> tuple[
    dict[str, frozenset[tuple[str, str]]],
    dict[tuple[str, str], frozenset[tuple[str, str]]],
    dict[str, frozenset[str]],
]:
    """Load Princeton WordNet 3.1 synsets, direct links, and lexicographer domains."""
    lemma_to_synsets: dict[str, set[tuple[str, str]]] = defaultdict(set)
    lemma_to_categories: dict[str, set[str]] = defaultdict(set)
    adjacency: dict[tuple[str, str], set[tuple[str, str]]] = defaultdict(set)
    for filename, pos in (('data.noun', 'n'), ('data.verb', 'v'), ('data.adj', 'a')):
        with open(ROOT / 'wordnet' / filename, encoding='utf-8') as f:
            for line in f:
                if not line or not line[0].isdigit():
                    continue
                fields = line.split('|', 1)[0].strip().split()
                try:
                    offset = fields[0]
                    lex_filenum = fields[1]
                    word_count = int(fields[3], 16)
                except (IndexError, ValueError):
                    continue
                synset = (pos, offset)
                for index in range(word_count):
                    word = fields[4 + 2 * index].lower().replace('_', ' ')
                    if word.isalpha():
                        lemma_to_synsets[word].add(synset)
                        # Adjective lexicographer classes 00/44 are too broad to be useful.
                        if lex_filenum not in {'00', '44'}:
                            lemma_to_categories[word].add(f'{pos}:{lex_filenum}')
                pointer_index = 4 + 2 * word_count
                try:
                    pointer_count = int(fields[pointer_index])
                except (IndexError, ValueError):
                    continue
                pointer_index += 1
                for _ in range(pointer_count):
                    if pointer_index + 3 >= len(fields):
                        break
                    _symbol, target_offset, target_pos, _source_target = fields[pointer_index:pointer_index + 4]
                    pointer_index += 4
                    target_pos = 'a' if target_pos == 's' else target_pos
                    target = (target_pos, target_offset)
                    adjacency[synset].add(target)
                    adjacency[target].add(synset)
    return (
        {lemma: frozenset(ids) for lemma, ids in lemma_to_synsets.items()},
        {synset: frozenset(neighbors) for synset, neighbors in adjacency.items()},
        {lemma: frozenset(categories) for lemma, categories in lemma_to_categories.items()},
    )


def attach_semantic_graphs(meta: dict[str, Meta], ru_synsets: dict[str, frozenset[str]],
                           wn_lemmas: dict[str, frozenset[tuple[str, str]]],
                           wn_adjacency: dict[tuple[str, str], frozenset[tuple[str, str]]],
                           wn_categories: dict[str, frozenset[str]]) -> None:
    """Attach Russian synsets and a conservative English semantic neighborhood."""
    for lemma, item in meta.items():
        item.ru_synsets = ru_synsets.get(lemma, frozenset())
        starts: set[tuple[str, str]] = set()
        categories: set[str] = set()
        for token in item.tokens:
            starts.update(wn_lemmas.get(token, ()))
            categories.update(wn_categories.get(token, ()))
        item.wn_synsets = frozenset(starts)
        item.wn_categories = frozenset(categories)
        # Same synset or one direct lexical/semantic relation is considered too close.
        reached = set(starts)
        for synset in starts:
            reached.update(wn_adjacency.get(synset, ()))
        item.wn_near = frozenset(reached)


def load_metadata(verb_valency: dict[str, tuple[str, ...]], corpus_valency: dict[str, tuple[tuple[str, ...], int]]) -> dict[str, Meta]:
    result: dict[str, Meta] = {}
    specs = [
        ('N', ROOT / 'openrussian_nouns.csv'),
        ('V', ROOT / 'openrussian_verbs.csv'),
        ('ADJ', ROOT / 'openrussian_adjectives.csv'),
        ('OTHER', ROOT / 'openrussian_others.csv'),
    ]
    for pos, path in specs:
        with open(path, encoding='utf-8-sig', newline='') as f:
            for row in csv.DictReader(f, delimiter='\t'):
                lemma = nfc_lower(row.get('bare', ''))
                if not CYR.fullmatch(lemma):
                    continue
                tr = (row.get('translations_en') or '').strip()
                tokens = clean_en_tokens(tr)
                m = Meta(pos=pos, translation=tr, tokens=tokens, classes=semantic_classes(tokens))
                if pos == 'N':
                    m.gender = (row.get('gender') or '').strip()
                    m.animate = (row.get('animate') or '').strip()
                    m.indeclinable = (row.get('indeclinable') or '').strip()
                elif pos == 'V':
                    m.aspect = (row.get('aspect') or '').strip()
                    m.reflexive = lemma.endswith(('ся', 'сь'))
                    m.valency = verb_valency.get(lemma, ())
                    m.corpus_valency, m.corpus_occurrences = corpus_valency.get(lemma, ((), 0))
                result.setdefault(lemma, m)
    return result


def load_lemma_records(whitelist: set[str], freq_rank: dict[str, int], meta: dict[str, Meta]) -> dict[str, LemmaRecord]:
    form_lemmas: dict[str, set[str]] = defaultdict(set)
    form_tags: dict[str, set[str]] = defaultdict(set)

    with open(ROOT / 'unimorph_rus.tsv', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            parts = line.rstrip('\n').split('\t')
            if len(parts) < 3:
                continue
            lemma = nfc_lower(parts[0])
            form = nfc_lower(parts[1])
            tag = parts[2].strip().upper()
            if lemma not in meta or lemma not in freq_rank:
                continue
            m = meta[lemma]
            if m.pos not in POS_ALLOWED:
                continue
            if lemma in RU_FUNCTION_EXCLUDE:
                continue
            if not m.tokens:
                continue
            if not CYR.fullmatch(lemma) or not CYR.fullmatch(form):
                continue
            if len(form) < 3 or form not in whitelist:
                continue
            # Retain only surface forms actually present in the 50k frequency list.
            # This removes theoretically generated but unattested paradigm forms.
            if form not in freq_rank:
                continue
            if not tag.startswith(TAG_ALLOWED_PREFIX[m.pos]):
                continue
            # Exclude analytic/multiword forms (regex already does) and rare non-finite verb classes.
            form_lemmas[form].add(lemma)
            form_tags[form].add(tag)

    records: dict[str, LemmaRecord] = {}
    for form, lemmas in form_lemmas.items():
        # Surface form must resolve to one lemma in the selected lexicon.
        if len(lemmas) != 1:
            continue
        lemma = next(iter(lemmas))
        m = meta[lemma]
        tags = tuple(sorted(form_tags[form]))
        major_pos = {t.split(';', 1)[0].split('.', 1)[0] for t in tags}
        if major_pos != {m.pos}:
            continue
        signature = (m.pos, tags)
        rec = records.setdefault(lemma, LemmaRecord(lemma=lemma, meta=m, rank=freq_rank[lemma]))
        # One surface per complete ambiguity signature. Prefer explicitly frequent surface forms.
        eff_rank = freq_rank[form]
        old = rec.forms.get(signature)
        if old is None or eff_rank < rec.form_rank[signature] or (eff_rank == rec.form_rank[signature] and form < old):
            rec.forms[signature] = form
            rec.form_rank[signature] = eff_rank

    # Require enough reliable forms and sane metadata.
    cleaned: dict[str, LemmaRecord] = {}
    for lemma, rec in records.items():
        if rec.meta.pos == 'N' and rec.meta.gender not in {'m', 'f', 'n'}:
            continue
        if rec.meta.pos == 'V' and (rec.meta.aspect not in {'perfective', 'imperfective'} or not rec.meta.valency or not rec.meta.corpus_valency):
            continue
        if len(rec.forms) < 1:
            continue
        cleaned[lemma] = rec
    return cleaned


def semantic_pair_ok(a: LemmaRecord, b: LemmaRecord) -> bool:
    if a.lemma == b.lemma or a.coarse_key != b.coarse_key:
        return False
    if lemma_related(a.lemma, b.lemma):
        return False
    # RuWordNet: never pair lemmas sharing any manually curated synonym set.
    if a.meta.ru_synsets and b.meta.ru_synsets and not a.meta.ru_synsets.isdisjoint(b.meta.ru_synsets):
        return False
    # Princeton WordNet over English gloss tokens: reject shared broad domains and direct links.
    if a.meta.wn_categories and b.meta.wn_categories and not a.meta.wn_categories.isdisjoint(b.meta.wn_categories):
        return False
    if (a.meta.wn_synsets and b.meta.wn_near and not a.meta.wn_synsets.isdisjoint(b.meta.wn_near)) or \
       (b.meta.wn_synsets and a.meta.wn_near and not b.meta.wn_synsets.isdisjoint(a.meta.wn_near)):
        return False
    ta, tb = set(a.meta.tokens), set(b.meta.tokens)
    if not ta or not tb or ta & tb:
        return False
    if a.meta.classes and b.meta.classes and not a.meta.classes.isdisjoint(b.meta.classes):
        return False
    # Translation-string similarity catches alternative spellings and near duplicate glosses.
    if ratio(' '.join(a.meta.tokens), ' '.join(b.meta.tokens)) >= 48:
        return False
    # Reject obvious derivational cross-links visible in gloss phrases.
    if a.lemma in b.meta.translation.lower() or b.lemma in a.meta.translation.lower():
        return False
    return True


def shared_form_rows(a: LemmaRecord, b: LemmaRecord) -> list[PairRow]:
    rows: list[PairRow] = []
    for sig in set(a.forms) & set(b.forms):
        sa, sb = a.forms[sig], b.forms[sig]
        if sa == sb:
            continue
        # Exact surface-form ambiguity signatures must be equal by dictionary key.
        overlap = len(set(a.meta.tokens) & set(b.meta.tokens))
        rows.append(PairRow(
            source=sa,
            target=sb,
            source_lemma=a.lemma,
            target_lemma=b.lemma,
            pos=a.meta.pos,
            signature=sig,
            grammar_class=a.coarse_key,
            source_rank=min(a.rank, a.form_rank.get(sig, 10**9)),
            target_rank=min(b.rank, b.form_rank.get(sig, 10**9)),
            source_translation=a.meta.translation,
            target_translation=b.meta.translation,
            semantic_token_overlap=overlap,
            source_classes=tuple(sorted(a.meta.classes)),
            target_classes=tuple(sorted(b.meta.classes)),
        ))
    return rows


def row_priority(row: PairRow) -> tuple:
    tags = row.signature[1]
    tag_text = '|'.join(tags)
    if row.pos == 'N':
        preferred = ['N;NOM;SG', 'N;ACC;SG', 'N;GEN;SG', 'N;DAT;SG', 'N;INS;SG', 'N;ESS;SG',
                     'N;NOM;PL', 'N;ACC;PL', 'N;GEN;PL', 'N;DAT;PL', 'N;INS;PL', 'N;ESS;PL']
    elif row.pos == 'V':
        preferred = ['V;NFIN', 'V;PST;SG;MASC', 'V;PST;SG;FEM', 'V;PST;PL', 'V;PRS;3;SG',
                     'V;FUT;3;SG', 'V;PRS;3;PL', 'V;FUT;3;PL', 'V;PRS;1;SG', 'V;FUT;1;SG',
                     'V;PRS;2;SG', 'V;FUT;2;SG', 'V;IMP;2;SG', 'V;IMP;2;PL']
    else:
        preferred = ['ADJ;NOM;MASC;SG', 'ADJ;NOM;FEM;SG', 'ADJ;NOM;NEUT;SG', 'ADJ;NOM;PL',
                     'ADJ;GEN;MASC;SG', 'ADJ;GEN;FEM;SG', 'ADJ;ACC;FEM;SG', 'ADJ;INS;PL']
    idx = min((i for i, x in enumerate(preferred) if x in tag_text), default=99)
    exact_rank = min(row.source_rank, row.target_rank)
    return (idx, exact_rank, max(row.source_rank, row.target_rank), row.source, row.target)


def pair_score(a: LemmaRecord, b: LemmaRecord, previous_pairs: set[frozenset[str]], rng: random.Random) -> tuple | None:
    if not semantic_pair_ok(a, b):
        return None
    logical = frozenset((a.lemma, b.lemma))
    if logical in previous_pairs:
        return None
    shared = len(set(a.forms) & set(b.forms))
    if shared < 1:
        return None
    class_diff = 1 if a.meta.classes and b.meta.classes and a.meta.classes.isdisjoint(b.meta.classes) else 0
    transl_sim = ratio(' '.join(a.meta.tokens), ' '.join(b.meta.tokens))
    lemma_sim = ratio(a.lemma, b.lemma)
    # Maximize shared forms and semantic separation, lightly favor frequency.
    return (
        class_diff,
        shared,
        -transl_sim,
        -lemma_sim,
        -max(a.rank, b.rank),
        -min(a.rank, b.rank),
        rng.random(),
    )


def build_lemma_pairs(records: dict[str, LemmaRecord], seed: int, previous_pairs: set[frozenset[str]], max_rank: int = 30000) -> list[tuple[LemmaRecord, LemmaRecord]]:
    rng = random.Random(seed)
    groups: dict[tuple, list[LemmaRecord]] = defaultdict(list)
    for rec in records.values():
        if rec.rank <= max_rank:
            groups[rec.coarse_key].append(rec)

    result: list[tuple[LemmaRecord, LemmaRecord]] = []
    for key, group in sorted(groups.items(), key=lambda kv: str(kv[0])):
        # Rank bands avoid pairing only rare words after the first few hundred pairs.
        group.sort(key=lambda r: (r.rank, r.lemma))
        available = group[:]
        # Seed-specific stable perturbation inside windows.
        for i in range(0, len(available), 80):
            block = available[i:i+80]
            rng.shuffle(block)
            available[i:i+80] = block

        while len(available) >= 2:
            a = available.pop(0)
            # Search a wide rotating sample. This remains deterministic and scales well.
            if len(available) <= 120:
                idxs = list(range(len(available)))
            else:
                start = rng.randrange(len(available))
                idxs = [(start + j * 37) % len(available) for j in range(120)]
            best_idx = None
            best_score = None
            for idx in idxs:
                b = available[idx]
                score = pair_score(a, b, previous_pairs, rng)
                if score is not None and (best_score is None or score > best_score):
                    best_score = score
                    best_idx = idx
            if best_idx is None:
                continue
            b = available.pop(best_idx)
            result.append((a, b))
    # Globally favor high-frequency lemma pairs with broad shared paradigms.
    result.sort(key=lambda ab: (max(ab[0].rank, ab[1].rank), min(ab[0].rank, ab[1].rank), ab[0].lemma, ab[1].lemma))
    return result


CURATED_OMEGA_PAIRS = [
    # Coordinating/subordinating conjunctions and case-compatible prepositions.
    ('и','но'), ('а','либо'), ('если','чтобы'), ('хотя','когда'),
    ('без','для'), ('до','после'), ('перед','между'), ('через','про'),
    # Temporal adverbs.
    ('уже','никогда'), ('теперь','давно'), ('сейчас','потом'), ('сегодня','всегда'),
    ('снова','наконец'), ('опять','прежде'), ('иногда','сразу'), ('рано','поздно'),
    ('скоро','вчера'), ('сначала','затем'),
    # Locative/directional adverbs.
    ('здесь','вокруг'), ('там','домой'), ('туда','рядом'), ('сюда','далеко'),
    ('куда','внутри'),
    # Manner adverbs.
    ('быстро','тихо'), ('легко','прямо'), ('хорошо','отдельно'), ('вместе','медленно'),
    ('иначе','обычно'), ('практически','точно'),
    # Degree/intensity adverbs.
    ('очень','мало'), ('более','чуть'), ('почти','полностью'), ('совсем','немного'),
    ('слишком','достаточно'), ('сильно','едва'), ('совершенно','частично'),
    # Discourse/epistemic adverbs.
    ('конечно','возможно'), ('действительно','например'), ('именно','вообще'),
    ('особенно','вероятно'), ('просто','формально'), ('обычно','случайно'),
]


def curated_omega_rows(whitelist: set[str], freq_rank: dict[str, int], meta: dict[str, Meta]) -> list[PairRow]:
    used: set[str] = set()
    rows: list[PairRow] = []
    for a, b in CURATED_OMEGA_PAIRS:
        a, b = nfc_lower(a), nfc_lower(b)
        if a == b or a in used or b in used:
            continue
        if a not in whitelist or b not in whitelist:
            continue
        ma, mb = meta.get(a), meta.get(b)
        rows.append(PairRow(
            source=a,
            target=b,
            source_lemma=a,
            target_lemma=b,
            pos='FUNCTION/ADV',
            signature=('CURATED_COMPATIBLE_CLASS',),
            grammar_class=('CURATED_COMPATIBLE_CLASS',),
            source_rank=freq_rank.get(a, 10**9),
            target_rank=freq_rank.get(b, 10**9),
            source_translation=ma.translation if ma else '',
            target_translation=mb.translation if mb else '',
            semantic_token_overlap=len(set(ma.tokens if ma else ()) & set(mb.tokens if mb else ())),
            source_classes=tuple(sorted(ma.classes)) if ma else (),
            target_classes=tuple(sorted(mb.classes)) if mb else (),
            curated=True,
        ))
        used.update((a, b))
    return rows


def make_mapping(name: str, records: dict[str, LemmaRecord], target: int, seed: int,
                 previous_lemma_pairs: set[frozenset[str]], whitelist: set[str],
                 freq_rank: dict[str, int], meta: dict[str, Meta]) -> tuple[list[PairRow], set[frozenset[str]]]:
    lemma_pairs = build_lemma_pairs(records, seed, previous_lemma_pairs, max_rank=50000 if name != 'omega' else 15000)
    rows: list[PairRow] = []
    used_words: set[str] = set()
    selected_lemma_pairs: set[frozenset[str]] = set()

    if name == 'omega':
        for row in curated_omega_rows(whitelist, freq_rank, meta):
            if row.source not in used_words and row.target not in used_words:
                rows.append(row)
                used_words.update((row.source, row.target))

    # Round-robin through lemma pairs: take highly useful forms first from every pair,
    # then progressively less common forms. This protects frequency coverage.
    per_pair_rows: list[tuple[tuple[LemmaRecord, LemmaRecord], list[PairRow]]] = []
    for a, b in lemma_pairs:
        candidate_rows = sorted(shared_form_rows(a, b), key=row_priority)
        if candidate_rows:
            per_pair_rows.append(((a, b), candidate_rows))

    depth = 0
    while len(rows) < target:
        added = 0
        for (a, b), candidates in per_pair_rows:
            if depth >= len(candidates):
                continue
            row = candidates[depth]
            if row.source in used_words or row.target in used_words:
                continue
            rows.append(row)
            used_words.update((row.source, row.target))
            selected_lemma_pairs.add(frozenset((a.lemma, b.lemma)))
            added += 1
            if len(rows) == target:
                break
        if len(rows) == target:
            break
        if added == 0 and all(depth + 1 >= len(c) for _, c in per_pair_rows):
            break
        depth += 1

    if len(rows) < target:
        raise RuntimeError(f'{name}: only generated {len(rows)} of {target} logical pairs')

    # Stable order: most frequent first, curated first in omega.
    rows.sort(key=lambda r: (not r.curated, max(r.source_rank, r.target_rank), min(r.source_rank, r.target_rank), r.source, r.target))
    return rows[:target], selected_lemma_pairs


def validate_rows(name: str, rows: list[PairRow], target: int, whitelist: set[str]) -> dict:
    words = [w for r in rows for w in (r.source, r.target)]
    errors: list[str] = []
    if len(rows) != target:
        errors.append(f'logical pair count {len(rows)} != {target}')
    if len(words) != len(set(words)):
        dup = [w for w, c in Counter(words).items() if c > 1][:20]
        errors.append(f'duplicate words: {dup}')
    for i, r in enumerate(rows):
        if r.source == r.target:
            errors.append(f'identity at row {i}: {r.source}')
        for w in (r.source, r.target):
            if w != nfc_lower(w) or not CYR.fullmatch(w):
                errors.append(f'unsafe token at row {i}: {w!r}')
            if w not in whitelist:
                errors.append(f'not in source dictionary at row {i}: {w}')
        if not r.curated:
            if r.semantic_token_overlap:
                errors.append(f'semantic token overlap at row {i}: {r.source}/{r.target}')
            if r.signature[0] != r.pos:
                errors.append(f'POS/signature mismatch at row {i}')
    mapping = {}
    for r in rows:
        mapping[r.source] = r.target
        mapping[r.target] = r.source
    if len(mapping) != target * 2:
        errors.append(f'directed mapping count {len(mapping)} != {target*2}')
    for k, v in mapping.items():
        if mapping.get(v) != k:
            errors.append(f'non-involution: {k}->{v}->{mapping.get(v)}')
            break
    if errors:
        raise RuntimeError(name + ' validation errors:\n' + '\n'.join(errors[:100]))

    pos_counts = Counter(r.pos for r in rows)
    ranks = [x for r in rows for x in (r.source_rank, r.target_rank) if x < 10**9]
    return {
        'name': name,
        'logical_pairs': len(rows),
        'directed_entries': len(mapping),
        'unique_words': len(set(words)),
        'source_dictionary_membership_pct': 100.0,
        'nfc_lowercase_cyrillic_pct': 100.0,
        'involution_pass': True,
        'identity_mappings': 0,
        'duplicate_words': 0,
        'semantic_token_overlap_rows': sum(bool(r.semantic_token_overlap) for r in rows if not r.curated),
        'curated_rows': sum(r.curated for r in rows),
        'content_rows': sum(not r.curated for r in rows),
        'content_share_pct': round(100 * sum(not r.curated for r in rows) / len(rows), 3),
        'pos_counts': dict(pos_counts),
        'median_frequency_rank': int(sorted(ranks)[len(ranks)//2]) if ranks else None,
        'top_10000_word_share_pct': round(100 * sum(x <= 10000 for x in ranks) / len(ranks), 3) if ranks else None,
        'top_20000_word_share_pct': round(100 * sum(x <= 20000 for x in ranks) / len(ranks), 3) if ranks else None,
    }


def write_outputs(name: str, rows: list[PairRow], stats: dict):
    # Flat, strictly bidirectional mapping compatible with simple dictionary lookup.
    mapping: dict[str, str] = {}
    for r in rows:
        mapping[r.source] = r.target
        mapping[r.target] = r.source
    with open(OUT / 'mappings' / f'{name}.json', 'w', encoding='utf-8', newline='\n') as f:
        json.dump(mapping, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write('\n')

    with open(OUT / 'pairs' / f'{name}.csv', 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['source', 'target'])
        w.writerows((r.source, r.target) for r in rows)

    fields = [
        'source','target','source_lemma','target_lemma','pos','morph_signature','grammar_class',
        'source_rank','target_rank','source_translation','target_translation',
        'semantic_token_overlap','source_classes','target_classes','curated'
    ]
    with open(OUT / 'audit' / f'{name}_audit.csv', 'w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({
                'source': r.source,
                'target': r.target,
                'source_lemma': r.source_lemma,
                'target_lemma': r.target_lemma,
                'pos': r.pos,
                'morph_signature': json.dumps(r.signature, ensure_ascii=False, separators=(',', ':')),
                'grammar_class': json.dumps(r.grammar_class, ensure_ascii=False, separators=(',', ':')),
                'source_rank': '' if r.source_rank >= 10**9 else r.source_rank,
                'target_rank': '' if r.target_rank >= 10**9 else r.target_rank,
                'source_translation': r.source_translation,
                'target_translation': r.target_translation,
                'semantic_token_overlap': r.semantic_token_overlap,
                'source_classes': '|'.join(r.source_classes),
                'target_classes': '|'.join(r.target_classes),
                'curated': int(r.curated),
            })


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description='Build deterministic Russian bidirectional mappings.')
    parser.add_argument('--data-dir', type=Path, default=Path('data'), help='Directory containing canonical source filenames.')
    parser.add_argument('--output-dir', type=Path, default=Path('out'), help='Output directory.')
    parser.add_argument('--no-archive', action='store_true', help='Do not create a ZIP archive beside the output directory.')
    return parser.parse_args()


def main():
    global ROOT, OUT
    args = parse_args()
    ROOT = args.data_dir.resolve()
    OUT = args.output_dir.resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'mappings').mkdir(exist_ok=True)
    (OUT / 'pairs').mkdir(exist_ok=True)
    (OUT / 'audit').mkdir(exist_ok=True)

    whitelist = load_whitelist()
    freq_rank, freq_order = load_frequency()
    verb_valency = load_apertium_valency()
    corpus_valency = load_syntagrus_valency()
    meta = load_metadata(verb_valency, corpus_valency)
    ru_synsets = load_ruwordnet_synsets()
    wn_lemmas, wn_adjacency, wn_categories = load_english_wordnet()
    attach_semantic_graphs(meta, ru_synsets, wn_lemmas, wn_adjacency, wn_categories)
    records = load_lemma_records(whitelist, freq_rank, meta)

    build_stats = {
        'source_dictionary_unique_lowercase_cyrillic_forms': len(whitelist),
        'frequency_ranked_forms': len(freq_rank),
        'metadata_lemmas': len(meta),
        'apertium_verb_valency_lemmas': len(verb_valency),
        'syntagrus_corpus_valency_lemmas': len(corpus_valency),
        'ruwordnet_single_word_lemmas': len(ru_synsets),
        'english_wordnet_lemmas': len(wn_lemmas),
        'eligible_lemmas': len(records),
        'eligible_forms': sum(len(r.forms) for r in records.values()),
        'eligible_pos_counts': dict(Counter(r.meta.pos for r in records.values())),
    }

    all_rows: dict[str, list[PairRow]] = {}
    all_stats: dict[str, dict] = {}
    previous_lemma_pairs: set[frozenset[str]] = set()
    for name in ('alpha', 'beta', 'gamma', 'omega'):
        rows, selected_pairs = make_mapping(
            name, records, TARGETS[name], SEEDS[name], previous_lemma_pairs,
            whitelist, freq_rank, meta,
        )
        # Prevent exact lemma-pair reuse for sibling reseeds. Omega is also kept independent.
        previous_lemma_pairs |= selected_pairs
        stats = validate_rows(name, rows, TARGETS[name], whitelist)
        all_rows[name] = rows
        all_stats[name] = stats
        write_outputs(name, rows, stats)

    # Cross-mapping diagnostics. Word overlap is expected for reseeds; pair overlap should be zero.
    pair_sets = {
        n: {frozenset((r.source, r.target)) for r in rows}
        for n, rows in all_rows.items()
    }
    word_sets = {
        n: {w for r in rows for w in (r.source, r.target)}
        for n, rows in all_rows.items()
    }
    cross = {}
    names = list(all_rows)
    for i, a in enumerate(names):
        for b in names[i+1:]:
            cross[f'{a}__{b}'] = {
                'exact_logical_pair_overlap': len(pair_sets[a] & pair_sets[b]),
                'word_overlap': len(word_sets[a] & word_sets[b]),
                'jaccard_word_overlap': round(len(word_sets[a] & word_sets[b]) / len(word_sets[a] | word_sets[b]), 6),
            }

    manifest = {
        'format': 'flat_bidirectional_word_mapping',
        'language': 'ru',
        'normalization': 'Unicode NFC, lowercase',
        'generated_from_user_dictionary': 'russian.dic',
        'count_semantics': 'directed_entries = 2 * logical_pairs',
        'seeds': SEEDS,
        'build': build_stats,
        'mappings': all_stats,
        'cross_mapping_checks': cross,
        'files': {},
    }
    # File hashes are populated after all reports and tools have been written.

    report_lines = [
        '# Отчёт о построении и проверке русскоязычных mappings',
        '',
        '## Результат',
        '',
        '| Набор | Логических пар | Направленных записей | Доля содержательных пар | Медианный частотный ранг | Доля слов из top-10k |',
        '|---|---:|---:|---:|---:|---:|',
    ]
    for n in names:
        s = all_stats[n]
        report_lines.append(
            f"| {n} | {s['logical_pairs']:,} | {s['directed_entries']:,} | {s['content_share_pct']:.3f}% | {s['median_frequency_rank']:,} | {s['top_10000_word_share_pct']:.3f}% |".replace(',', ' ')
        )
    report_lines += [
        '',
        '## Автоматические проверки',
        '',
        '- Все записи присутствуют в приложенном `russian.dic` в нижнем регистре.',
        '- Все токены состоят только из русских букв, нормализованы в Unicode NFC и не содержат пробелов, дефисов, цифр или пунктуации.',
        '- Внутри каждого набора каждое слово встречается ровно один раз.',
        '- Каждая логическая пара развёрнута в JSON в две стороны; для каждого ключа выполнено `mapping[mapping[word]] == word`.',
        '- Для содержательных пар совпадает полный набор тегов UniMorph; дополнительно совпадают род/одушевлённость у существительных и вид/возвратность/класс переходности Apertium у глаголов.',
        '- Пары одной леммы, близкие русские написания и пары с пересекающимися значимыми словами английских толкований исключены.',
        '- Точные логические пары между вариантами не повторяются.',
        '',
        '## Ограничения проверки',
        '',
        '- Частотный список ранжирует леммы; он не содержит абсолютных частот всех словоформ. Поэтому показатели частотности являются ранговым приближением, а не измерением покрытия конкретного корпуса.',
        '- Автоматический семантический veto использует толкования OpenRussian, пересечение значимых слов, грубые семантические классы и проверку сходства написания. Это не заменяет ручную лингвистическую экспертизу каждой из десятков тысяч направленных записей.',
        '- Для глаголов проверены вид, возвратность, класс переходности и совпадение морфологических форм. Однако конкретное падежное управление и набор семантических актантов полностью не представлены; перед заявлением production-grade качества рекомендуется корпусный тест контекстной взаимозаменяемости и ручная выборочная экспертиза.',
        '- `omega` является coverage-oriented русским вариантом с небольшим числом вручную отобранных пар служебных слов/наречий; он не является переводом английского M15-EN.',
        '',
        '## Форматы файлов',
        '',
        '- `mappings/*.json` — плоский строго двунаправленный словарь.',
        '- `pairs/*.csv` — каждая логическая пара записана один раз.',
        '- `audit/*_audit.csv` — морфологические, частотные и семантические данные для проверки.',
        '- `manifest.json` — размеры, контрольные суммы и результаты автоматических проверок.',
    ]
    (OUT / 'QUALITY_REPORT.md').write_text('\n'.join(report_lines) + '\n', encoding='utf-8')

    sources = '''# Источники данных и атрибуция

1. Пользовательский архив `russian.dic(1).zip`: использован как обязательный белый список допустимых словоформ. Лицензия в архиве не указана.
2. UniMorph Russian (`unimorph/rus`): леммы и морфологические теги; источник проекта указывает Wikipedia и CC BY-SA 3.0.
3. OpenRussian dictionary (`Badestrand/russian-dictionary`): части речи, род, одушевлённость, вид и английские толкования; CC BY-SA 4.0. Авторы предупреждают, что резервные CSV устарели и могут содержать артефакты.
4. Apertium Russian (`apertium/apertium-rus`): классы переходности глаголов; GPL-3.0.
5. `hingston/russian`: ранжированный список 50 000 кириллических слов по частотности корпуса University of Leeds.
6. Universal Dependencies Russian SynTagRus: корпусные профили глагольного управления; CC BY-NC-SA 4.0. В связи с условием NC итоговый набор следует считать непригодным для коммерческого распространения без отдельной проверки прав.
7. RuWordNet 2.0: синсетный veto для русских лемм. Исходный тезаурус предоставляется для некоммерческого использования; условия правообладателя требуют отдельной проверки перед распространением.
8. Princeton WordNet 3.1 (`moos/wordnet-db`): граф семантической близости английских толкований; Princeton WordNet License.

Итоговые mappings являются автоматически сформированным производным набором. При распространении следует проверить и соблюдать условия лицензий исходных наборов данных.
'''
    (OUT / 'DATA_SOURCES_AND_LICENSES.md').write_text(sources, encoding='utf-8')

    # Self-contained validator delivered with the files.
    validator = r'''#!/usr/bin/env python3
import json, pathlib, sys, unicodedata, re
CYR = re.compile(r'^[а-яё]+$')
base = pathlib.Path(__file__).resolve().parent
expected = {'alpha':11970,'beta':12034,'gamma':12036,'omega':2534}
failed = False
for name, count in expected.items():
    p = base/'mappings'/f'{name}.json'
    m = json.loads(p.read_text(encoding='utf-8'))
    errs=[]
    if len(m)!=count: errs.append(f'count={len(m)}, expected={count}')
    for k,v in m.items():
        if k==v: errs.append(f'identity {k}')
        if m.get(v)!=k: errs.append(f'non-involution {k}->{v}->{m.get(v)}')
        if k!=unicodedata.normalize('NFC',k) or k!=k.lower() or not CYR.fullmatch(k): errs.append(f'unsafe {k!r}')
        if errs: break
    print(name, 'PASS' if not errs else 'FAIL', '; '.join(errs))
    failed |= bool(errs)
sys.exit(1 if failed else 0)
'''
    (OUT / 'validate_mappings.py').write_text(validator, encoding='utf-8')

    # Deliver the exact reproducible generator used for this build.
    (OUT / 'tools').mkdir(exist_ok=True)
    shutil.copy2(Path(__file__), OUT / 'tools' / 'build_ru_mappings.py')

    # Re-run validator directly.
    import subprocess, sys
    subprocess.run([sys.executable, str(OUT/'validate_mappings.py')], check=True)

    # Populate checksums after all files exist. Manifest itself is omitted to avoid recursive hashing.
    manifest['files'] = {}
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.name != 'manifest.json':
            manifest['files'][str(p.relative_to(OUT))] = {'bytes': p.stat().st_size, 'sha256': sha256(p)}
    with open(OUT / 'manifest.json', 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write('\n')

    # Archive all outputs.
    archive = OUT.parent / f'{OUT.name}.zip'
    if not args.no_archive:
        if archive.exists():
            archive.unlink()
        with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
            for p in sorted(OUT.rglob('*')):
                if p.is_file():
                    zf.write(p, arcname=str(Path(OUT.name) / p.relative_to(OUT)))

    print(json.dumps({'archive': None if args.no_archive else str(archive), 'output_dir': str(OUT), 'build': build_stats, 'mappings': all_stats, 'cross': cross}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
