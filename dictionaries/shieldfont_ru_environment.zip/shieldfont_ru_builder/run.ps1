param(
    [Parameter(Mandatory = $true)]
    [string]$Dictionary,
    [string]$OutputDir = ""
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($OutputDir)) {
    $OutputDir = Join-Path $Root "out"
}
$Venv = Join-Path $Root ".venv"
py -3.13 -m venv $Venv
$Python = Join-Path $Venv "Scripts\python.exe"
& $Python -m pip install --upgrade pip
& $Python -m pip install -r (Join-Path $Root "requirements.txt")
& $Python (Join-Path $Root "reproduce.py") --dictionary $Dictionary --output-dir $OutputDir
