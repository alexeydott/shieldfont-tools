# Воспроизводимая среда построения русских словарей

Архив содержит только инструменты, скрипты, конфигурацию и контрольные суммы. Исходный `russian.dic`, сторонние словари и корпуса в архив не включены.

## Что воспроизводится

При совпадении всех входных SHA-256 среда строит те же четыре набора:

| Набор | Логических пар | Направленных записей |
|---|---:|---:|
| alpha | 5 985 | 11 970 |
| beta | 6 017 | 12 034 |
| gamma | 6 018 | 12 036 |
| omega | 1 267 | 2 534 |

После построения `tools/verify_outputs.py` сравнивает побайтные SHA-256 файлов `mappings/*.json`, `pairs/*.csv` и `audit/*_audit.csv` с исходной сборкой. Успешный запуск заканчивается сообщением:

```text
REPRODUCTION PASS: all locked outputs are byte-identical to the original build.
```

## Самый надёжный запуск — Docker

Требуются Docker и доступ к GitHub для загрузки открытых источников.

```bash
docker build -t shieldfont-ru-builder .
docker run --rm \
  -v "/absolute/path/russian.dic(1).zip:/input/russian.dic.zip:ro" \
  -v "/absolute/path/output:/output" \
  shieldfont-ru-builder \
  --dictionary /input/russian.dic.zip \
  --data-dir /tmp/data \
  --output-dir /output
```

Для Windows PowerShell замените пути на абсолютные Windows-пути, доступные Docker Desktop.

## Запуск без Docker

Требуется Python 3.13. Исходная проверенная среда: Python 3.13.5 и RapidFuzz 3.14.3.

### Windows

```powershell
.\run.ps1 -Dictionary "C:\path\russian.dic(1).zip" -OutputDir "C:\path\result"
```

### Linux/macOS

```bash
./run.sh "/path/russian.dic(1).zip" "/path/result"
```

### Ручной запуск

```bash
python -m venv .venv
# Linux/macOS:
. .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1

python -m pip install -r requirements.txt
python reproduce.py --dictionary "/path/russian.dic(1).zip"
```

## Этапы `reproduce.py`

1. Проверяет Python и точную версию RapidFuzz.
2. Проверяет SHA-256 переданного архива `russian.dic`.
3. Скачивает остальные источники по зафиксированным GitHub revision URL.
4. Проверяет размер и SHA-256 каждого входного файла из `config/sources.lock.json`.
5. Удаляет прежний output, если не указан `--keep-output`.
6. Запускает детерминированный генератор с `PYTHONHASHSEED=0`, `TZ=UTC`, `C.UTF-8`.
7. Выполняет структурную проверку каждого двунаправленного mapping.
8. Сверяет результирующие файлы с `config/expected_outputs.json`.

При несовпадении хотя бы одного входа или выхода процесс завершается ненулевым кодом.

## Если источники уже загружены

Поместите файлы в каталог `data` под именами из `config/sources.lock.json`, затем выполните:

```bash
python reproduce.py \
  --dictionary "/path/russian.dic(1).zip" \
  --data-dir ./data \
  --output-dir ./out \
  --skip-download
```

## Содержимое

- `reproduce.py` — полный оркестратор.
- `tools/build_ru_mappings.py` — генератор, фактически использованный для построения наборов; изменены только пути и CLI.
- `tools/fetch_sources.py` — загрузчик открытых источников с обязательной проверкой SHA-256.
- `tools/verify_sources.py` — независимая проверка входов.
- `tools/verify_outputs.py` — побайтная проверка результатов.
- `tools/validate_mappings.py` — проверка размеров, двунаправленности и Unicode-инвариантов.
- `config/sources.lock.json` — имена, URL, размеры и SHA-256 входов.
- `config/expected_outputs.json` — размеры и SHA-256 эталонных результатов.
- `Dockerfile`, `run.sh`, `run.ps1` — воспроизводимый запуск.

## Границы гарантии

Побайтное воспроизведение гарантируется проверкой результата только при наличии исходного архива `russian.dic` с SHA-256:

```text
cf8eded45905baa02330b59773d68e2376d3e3a2eaf51aa26478e68b8cef8d5f
```

Внешние серверы могут стать недоступны в будущем. Это не приводит к незаметной смене данных: загрузчик остановится. Для долговременного воспроизведения сохраните отдельно все файлы, перечисленные в `config/sources.lock.json`, не изменяя их содержимое.

Сам алгоритм и автоматические проверки не являются заменой ручной лингвистической экспертизы всех пар. Среда воспроизводит именно ранее построенные и проверенные автоматическим pipeline наборы.
