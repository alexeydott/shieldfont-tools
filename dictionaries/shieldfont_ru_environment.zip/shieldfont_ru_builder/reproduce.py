#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TOOLS = ROOT / 'tools'


def run(command: list[str], env: dict[str, str] | None = None) -> None:
    print('+', subprocess.list2cmdline(command), flush=True)
    subprocess.run(command, check=True, env=env)


def main() -> int:
    parser = argparse.ArgumentParser(description='Reproduce the four Russian mapping sets and verify byte-identical outputs.')
    parser.add_argument('--dictionary', type=Path, required=True, help='Original russian.dic ZIP supplied to the build.')
    parser.add_argument('--data-dir', type=Path, default=ROOT / 'data')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'out')
    parser.add_argument('--skip-download', action='store_true', help='Use already populated data directory.')
    parser.add_argument('--keep-output', action='store_true', help='Do not delete an existing output directory.')
    parser.add_argument('--no-archive', action='store_true')
    args = parser.parse_args()

    try:
        import rapidfuzz
    except ImportError:
        print('rapidfuzz is not installed. Run: python -m pip install -r requirements.txt', file=sys.stderr)
        return 2
    if rapidfuzz.__version__ != '3.14.3':
        print(f'rapidfuzz {rapidfuzz.__version__} is installed; exact build requires 3.14.3.', file=sys.stderr)
        return 2
    if sys.version_info[:2] != (3, 13):
        print(f'Python {sys.version.split()[0]} detected; exact build was tested with Python 3.13.5.', file=sys.stderr)
        return 2

    if not args.skip_download:
        run([sys.executable, str(TOOLS / 'fetch_sources.py'), '--dictionary', str(args.dictionary), '--data-dir', str(args.data_dir)])
    else:
        canonical = args.data_dir / 'russian.dic(1).zip'
        canonical.parent.mkdir(parents=True, exist_ok=True)
        if args.dictionary.resolve() != canonical.resolve():
            shutil.copy2(args.dictionary, canonical)

    run([sys.executable, str(TOOLS / 'verify_sources.py'), '--data-dir', str(args.data_dir)])

    if args.output_dir.exists() and not args.keep_output:
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env.update({'PYTHONHASHSEED': '0', 'TZ': 'UTC', 'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8'})
    command = [sys.executable, str(TOOLS / 'build_ru_mappings.py'), '--data-dir', str(args.data_dir), '--output-dir', str(args.output_dir)]
    if args.no_archive:
        command.append('--no-archive')
    run(command, env=env)
    run([sys.executable, str(TOOLS / 'verify_outputs.py'), '--output-dir', str(args.output_dir)])
    print('REPRODUCTION PASS: all locked outputs are byte-identical to the original build.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
