#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(command: list[str], env: dict[str, str]) -> None:
    print("+", subprocess.list2cmdline(command), flush=True)
    subprocess.run(command, check=True, env=env)


def main() -> int:
    parser = argparse.ArgumentParser(description="Rebuild and validate the Russian v2 mapping family.")
    parser.add_argument("--dictionary", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "out")
    parser.add_argument("--base-font", type=Path)
    parser.add_argument("--verify-expected", action="store_true")
    args = parser.parse_args()

    try:
        import rapidfuzz
    except ImportError:
        print("Install requirements: python -m pip install -r requirements.txt", file=sys.stderr)
        return 2
    if rapidfuzz.__version__ != "3.14.3":
        print(f"rapidfuzz {rapidfuzz.__version__}; exact build requires 3.14.3", file=sys.stderr)
        return 2

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True)
    env = os.environ.copy()
    env.update({"PYTHONHASHSEED": "0", "TZ": "UTC", "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"})
    command = [
        sys.executable, str(ROOT / "tools" / "build_mapping_family.py"),
        "--pool", str(ROOT / "pool" / "ru_family_pool_v2.json"),
        "--dictionary", str(args.dictionary),
        "--config", str(ROOT / "config" / "build_config.json"),
        "--omega-curated", str(ROOT / "config" / "omega_curated_pairs.json"),
        "--omega-metadata", str(ROOT / "pool" / "omega_curated_words.json"),
        "--output-dir", str(args.output_dir),
    ]
    if args.base_font:
        command += ["--base-font", str(args.base_font)]
    run(command, env)
    run([
        sys.executable, str(ROOT / "tools" / "validate_family.py"),
        "--output-dir", str(args.output_dir),
        "--pool", str(ROOT / "pool" / "ru_family_pool_v2.json"),
        "--dictionary", str(args.dictionary),
        "--omega-curated", str(ROOT / "config" / "omega_curated_pairs.json"),
    ], env)

    if args.verify_expected:
        expected = json.loads((ROOT / "config" / "expected_outputs.json").read_text(encoding="utf-8"))
        actual = json.loads((args.output_dir / "manifest.json").read_text(encoding="utf-8"))["files"]
        mismatches = [name for name, info in expected["files"].items() if actual.get(name) != info]
        if mismatches:
            raise SystemExit("byte-identical verification failed: " + ", ".join(mismatches))
        print("BYTE-IDENTICAL REPRODUCTION PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
