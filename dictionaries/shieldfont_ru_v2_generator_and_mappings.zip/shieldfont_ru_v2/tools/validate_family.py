#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import unicodedata
import zipfile
from collections import Counter
from pathlib import Path

CYR = re.compile(r"^[а-яё]+$")
EXPECTED = {"alpha": 11970, "beta": 12034, "gamma": 12036, "omega": 2534}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_whitelist(path: Path) -> set[str]:
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        if len(names) != 1:
            raise RuntimeError("dictionary archive must contain exactly one file")
        return {
            unicodedata.normalize("NFC", line.strip().lower())
            for line in zf.read(names[0]).decode("utf-8").splitlines()
            if line == line.lower() and CYR.fullmatch(unicodedata.normalize("NFC", line.strip().lower()))
        }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate a generated Russian mapping family.")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--pool", type=Path, required=True)
    parser.add_argument("--dictionary", type=Path, required=True)
    parser.add_argument("--omega-curated", type=Path, required=True)
    args = parser.parse_args()

    output = args.output_dir.resolve()
    pool_raw = json.loads(args.pool.read_text(encoding="utf-8"))
    pool_words = {item["word"]: item for item in pool_raw["words"]}
    whitelist = load_whitelist(args.dictionary)
    curated_config = json.loads(args.omega_curated.read_text(encoding="utf-8"))
    curated_words = {w for p in curated_config["pairs"] for w in (p["source"], p["target"])}

    pair_sets: dict[str, set[frozenset[str]]] = {}
    word_sets: dict[str, set[str]] = {}
    summary: dict[str, dict] = {}

    for name, expected in EXPECTED.items():
        mapping_path = output / "mappings" / f"{name}.json"
        pairs_path = output / "pairs" / f"{name}.csv"
        audit_path = output / "audit" / f"{name}_audit.csv"
        raw = json.loads(mapping_path.read_text(encoding="utf-8"))
        meta = raw.get("_meta")
        if not isinstance(meta, dict):
            raise RuntimeError(f"{name}: missing _meta")
        mapping = {k: v for k, v in raw.items() if not k.startswith("_")}
        errors: list[str] = []
        if len(mapping) != expected:
            errors.append(f"directed count {len(mapping)} != {expected}")
        if meta.get("pairs") != expected or meta.get("logicalPairs") != expected // 2:
            errors.append("_meta count mismatch")
        if meta.get("candidatePoolSha256") != sha256(args.pool):
            errors.append("pool checksum mismatch")
        for source, target in mapping.items():
            if source == target:
                errors.append(f"identity {source}")
                break
            if mapping.get(target) != source:
                errors.append(f"non-involution {source}->{target}->{mapping.get(target)}")
                break
            if source != unicodedata.normalize("NFC", source) or source != source.lower() or not CYR.fullmatch(source):
                errors.append(f"unsafe token {source!r}")
                break
            if source not in whitelist:
                errors.append(f"not in russian.dic: {source}")
                break
            if name != "omega" or source not in curated_words:
                if source not in pool_words:
                    errors.append(f"active word absent from canonical pool: {source}")
                    break

        csv_pairs: list[tuple[str, str]] = []
        with pairs_path.open(encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                csv_pairs.append((row["source"], row["target"]))
        if len(csv_pairs) != expected // 2:
            errors.append("pairs CSV count mismatch")
        csv_pair_set = {frozenset(pair) for pair in csv_pairs}
        mapping_pair_set = {frozenset((source, target)) for source, target in mapping.items()}
        if csv_pair_set != mapping_pair_set:
            errors.append("pairs CSV differs from mapping JSON")

        audit_rows = list(csv.DictReader(audit_path.open(encoding="utf-8", newline="")))
        if len(audit_rows) != expected // 2:
            errors.append("audit count mismatch")
        for row in audit_rows:
            if row["curated"] == "0":
                if row["semantic_token_overlap"] != "0" or row["semantic_class_overlap"] != "0":
                    errors.append(f"semantic overlap in audit: {row['source']}/{row['target']}")
                    break
                source_meta = pool_words.get(row["source"])
                target_meta = pool_words.get(row["target"])
                if not source_meta or not target_meta or source_meta["bucket"] != target_meta["bucket"] or row["bucket"] != source_meta["bucket"]:
                    errors.append(f"bucket mismatch in audit: {row['source']}/{row['target']}")
                    break

        if errors:
            raise RuntimeError(name + ":\n" + "\n".join(errors))
        pair_sets[name] = csv_pair_set
        word_sets[name] = set(mapping)
        summary[name] = {
            "directedEntries": len(mapping),
            "logicalPairs": len(csv_pairs),
            "involution": "PASS",
            "dictionaryMembership": "PASS",
            "poolMembership": "PASS",
            "audit": "PASS",
        }

    overlap: dict[str, int] = {}
    names = list(EXPECTED)
    for i, left in enumerate(names):
        for right in names[i + 1:]:
            count = len(pair_sets[left] & pair_sets[right])
            overlap[f"{left}__{right}"] = count
            if count:
                raise RuntimeError(f"exact pair overlap {left}/{right}: {count}")

    manifest = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
    for relative, expected in manifest["files"].items():
        path = output / relative
        if not path.is_file() or path.stat().st_size != expected["bytes"] or sha256(path) != expected["sha256"]:
            raise RuntimeError(f"manifest mismatch: {relative}")

    result = {"status": "PASS", "variants": summary, "exactPairOverlap": overlap}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
