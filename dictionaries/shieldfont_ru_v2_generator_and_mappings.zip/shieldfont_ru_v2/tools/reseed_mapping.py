#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from build_mapping_family import load_pool, load_whitelist, match_variant, validate_pairs, write_variant, sha256


def main() -> int:
    parser = argparse.ArgumentParser(description="Create one private vetoed reseed from the canonical Russian candidate pool.")
    parser.add_argument("--pool", type=Path, required=True)
    parser.add_argument("--dictionary", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--logical-pairs", type=int, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--forbid-mapping", type=Path, action="append", default=[])
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    words, pool_meta = load_pool(args.pool)
    whitelist = load_whitelist(args.dictionary)
    forbidden: set[frozenset[str]] = set()
    for path in args.forbid_mapping:
        raw = json.loads(path.read_text(encoding="utf-8"))
        mapping = {k: v for k, v in raw.items() if not k.startswith("_")}
        forbidden.update(frozenset((source, target)) for source, target in mapping.items())

    pairs, build = match_variant(words.values(), args.seed, args.logical_pairs, forbidden, config["matching"])
    validation = validate_pairs(args.name, pairs, args.logical_pairs, whitelist)
    variant = {"mode": "reseed-vetoed", "seed": args.seed, "logicalPairs": args.logical_pairs}
    for subdir in ("mappings", "pairs", "audit", "stats"):
        (args.output_dir / subdir).mkdir(parents=True, exist_ok=True)
    write_variant(args.output_dir, args.name, pairs, variant, sha256(args.pool), pool_meta, build, validation, None)
    print(json.dumps({"name": args.name, "build": build, "validation": validation}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
