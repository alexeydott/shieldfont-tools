#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

EN_WORD = re.compile(r"[a-z]+")
EN_STOP = {
    "a", "an", "the", "to", "of", "in", "on", "at", "by", "for", "from", "with", "without",
    "and", "or", "but", "be", "is", "are", "was", "were", "been", "being", "do", "does", "did",
    "done", "have", "has", "had", "one", "ones", "someone", "something", "somebody", "some", "any",
    "it", "its", "this", "that", "these", "those", "as", "into", "onto", "upon", "about", "over",
    "under", "through", "out", "up", "down", "off", "not", "no", "person", "thing", "things", "etc",
    "usually", "especially", "also", "used", "use", "make", "get", "go",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def clean_tokens(text: str) -> list[str]:
    result: list[str] = []
    for token in EN_WORD.findall(text.lower()):
        if len(token) < 3 or token in EN_STOP:
            continue
        for suffix in ("ingly", "edly", "ation", "ments", "ment", "ness", "ities", "ity", "ing", "ed", "es", "s"):
            if token.endswith(suffix) and len(token) - len(suffix) >= 3:
                token = token[:-len(suffix)]
                break
        result.append(token)
    return sorted(set(result))


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a canonical Russian mapping candidate pool from audited mappings.")
    parser.add_argument("--audit-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    audit_paths = [args.audit_dir / f"{name}_audit.csv" for name in ("alpha", "beta", "gamma")]
    for path in audit_paths:
        if not path.is_file():
            raise SystemExit(f"missing audit file: {path}")

    words: dict[str, dict] = {}
    origins: dict[str, set[str]] = defaultdict(set)
    source_pairs: dict[frozenset[str], set[str]] = defaultdict(set)

    for path in audit_paths:
        variant = path.name.split("_", 1)[0]
        with path.open(encoding="utf-8", newline="") as f:
            for row in csv.DictReader(f):
                source_pairs[frozenset((row["source"], row["target"]))].add(variant)
                for side in ("source", "target"):
                    word = row[side]
                    signature = json.loads(row["morph_signature"])
                    grammar_class = json.loads(row["grammar_class"])
                    record = {
                        "word": word,
                        "lemma": row[f"{side}_lemma"],
                        "pos": row["pos"],
                        "morphSignature": signature,
                        "grammarClass": grammar_class,
                        "bucket": json.dumps(
                            {"pos": row["pos"], "morphSignature": signature, "grammarClass": grammar_class},
                            ensure_ascii=False,
                            sort_keys=True,
                            separators=(",", ":"),
                        ),
                        "frequencyRank": int(row[f"{side}_rank"]),
                        "translation": row[f"{side}_translation"],
                        "semanticTokens": clean_tokens(row[f"{side}_translation"]),
                        "semanticClasses": sorted(filter(None, row[f"{side}_classes"].split("|"))),
                    }
                    old = words.get(word)
                    if old is not None and old != record:
                        raise SystemExit(f"conflicting metadata for {word!r}: {old!r} != {record!r}")
                    words[word] = record
                    origins[word].add(variant)

    ordered_words = []
    for word, record in sorted(words.items(), key=lambda item: (item[1]["frequencyRank"], item[0])):
        record = dict(record)
        record["sourceVariants"] = sorted(origins[word])
        ordered_words.append(record)

    bucket_counts: dict[str, int] = defaultdict(int)
    for record in ordered_words:
        bucket_counts[record["bucket"]] += 1

    payload = {
        "_meta": {
            "schema": 2,
            "language": "ru",
            "normalization": "NFC lowercase",
            "poolId": "shieldfont-ru-family-pool-v2",
            "description": "Canonical candidate pool shared by alpha, beta and gamma. Every word has exactly one exact grammatical bucket.",
            "wordCount": len(ordered_words),
            "bucketCount": len(bucket_counts),
            "sourceAudits": [
                {"file": path.name, "sha256": sha256(path)} for path in audit_paths
            ],
            "sourcePairCount": len(source_pairs),
        },
        "buckets": [
            {"id": bucket, "words": count}
            for bucket, count in sorted(bucket_counts.items(), key=lambda item: item[0])
        ],
        "words": ordered_words,
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    print(json.dumps({"out": str(args.out), "words": len(ordered_words), "buckets": len(bucket_counts), "sha256": sha256(args.out)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
