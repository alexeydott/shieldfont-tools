#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import re
import unicodedata
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from rapidfuzz.fuzz import ratio

CYR = re.compile(r"^[а-яё]+$")
GENERATOR_VERSION = "2.0.0"


@dataclass(frozen=True)
class PoolWord:
    word: str
    lemma: str
    pos: str
    morph_signature: tuple
    grammar_class: tuple
    bucket: str
    rank: int
    translation: str
    semantic_tokens: tuple[str, ...]
    semantic_classes: tuple[str, ...]
    source_variants: tuple[str, ...]


@dataclass(frozen=True)
class Pair:
    source: PoolWord
    target: PoolWord
    bucket: str
    curated: bool = False


@dataclass(frozen=True)
class CuratedWord:
    word: str
    lemma: str
    rank: int
    translation: str
    semantic_classes: tuple[str, ...]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stable_hash(seed: int, *parts: object) -> int:
    payload = "|".join(str(x) for x in (seed, *parts)).encode("utf-8")
    return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "big")


def common_prefix_len(a: str, b: str) -> int:
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    return n


def lemma_related(a: str, b: str) -> bool:
    if a == b:
        return True
    shortest = min(len(a), len(b))
    if shortest <= 0:
        return True
    if ratio(a, b) >= 58:
        return True
    if shortest >= 5 and common_prefix_len(a, b) / shortest >= 0.65:
        return True
    if shortest >= 6 and common_prefix_len(a[::-1], b[::-1]) / shortest >= 0.70:
        return True
    return False


def semantic_pair_ok(a: PoolWord, b: PoolWord) -> bool:
    if a.word == b.word or a.bucket != b.bucket or a.lemma == b.lemma:
        return False
    if lemma_related(a.lemma, b.lemma):
        return False
    ta, tb = set(a.semantic_tokens), set(b.semantic_tokens)
    if not ta or not tb or ta & tb:
        return False
    if a.semantic_classes and b.semantic_classes and not set(a.semantic_classes).isdisjoint(b.semantic_classes):
        return False
    if ratio(" ".join(a.semantic_tokens), " ".join(b.semantic_tokens)) >= 48:
        return False
    if a.lemma in b.translation.lower() or b.lemma in a.translation.lower():
        return False
    return True


def pair_metrics(a: PoolWord, b: PoolWord) -> dict[str, int]:
    return {
        "translationSimilarity": ratio(" ".join(a.semantic_tokens), " ".join(b.semantic_tokens)),
        "lemmaSimilarity": ratio(a.lemma, b.lemma),
        "semanticTokenOverlap": len(set(a.semantic_tokens) & set(b.semantic_tokens)),
        "semanticClassOverlap": len(set(a.semantic_classes) & set(b.semantic_classes)),
    }


def load_pool(path: Path) -> tuple[dict[str, PoolWord], dict]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    words: dict[str, PoolWord] = {}
    for item in raw["words"]:
        record = PoolWord(
            word=item["word"],
            lemma=item["lemma"],
            pos=item["pos"],
            morph_signature=tuple(json.loads(json.dumps(item["morphSignature"], ensure_ascii=False))),
            grammar_class=tuple(json.loads(json.dumps(item["grammarClass"], ensure_ascii=False))),
            bucket=item["bucket"],
            rank=int(item["frequencyRank"]),
            translation=item["translation"],
            semantic_tokens=tuple(item["semanticTokens"]),
            semantic_classes=tuple(item["semanticClasses"]),
            source_variants=tuple(item.get("sourceVariants", ())),
        )
        if record.word in words:
            raise RuntimeError(f"duplicate pool word: {record.word}")
        words[record.word] = record
    if len(words) != raw["_meta"]["wordCount"]:
        raise RuntimeError("pool word count mismatch")
    return words, raw["_meta"]


def load_whitelist(archive: Path) -> set[str]:
    with zipfile.ZipFile(archive) as zf:
        names = zf.namelist()
        if len(names) != 1:
            raise RuntimeError(f"expected exactly one file in dictionary archive, got {names!r}")
        lines = zf.read(names[0]).decode("utf-8").splitlines()
    return {
        unicodedata.normalize("NFC", line.strip().lower())
        for line in lines
        if line == line.lower() and CYR.fullmatch(unicodedata.normalize("NFC", line.strip().lower()))
    }


def validate_pool(words: dict[str, PoolWord], whitelist: set[str], base_font: Path | None) -> dict:
    errors: list[str] = []
    bucket_for_word: dict[str, str] = {}
    for word, record in words.items():
        if word != unicodedata.normalize("NFC", word) or word != word.lower() or not CYR.fullmatch(word):
            errors.append(f"unsafe word {word!r}")
        if word not in whitelist:
            errors.append(f"word absent from russian.dic: {word}")
        previous = bucket_for_word.setdefault(word, record.bucket)
        if previous != record.bucket:
            errors.append(f"word assigned to multiple buckets: {word}")
    glyph_missing: list[str] = []
    if base_font is not None:
        try:
            from fontTools.ttLib import TTFont
        except ImportError as exc:
            raise RuntimeError("fontTools is required when --base-font is supplied") from exc
        font = TTFont(str(base_font), lazy=True)
        cmap = font.getBestCmap()
        required = set("".join(words)) | {c.upper() for c in set("".join(words))}
        glyph_missing = sorted(ch for ch in required if ord(ch) not in cmap)
        if glyph_missing:
            errors.append("base font is missing characters: " + " ".join(glyph_missing))
    if errors:
        raise RuntimeError("pool validation failed:\n" + "\n".join(errors[:100]))
    return {
        "wordCount": len(words),
        "bucketCount": len({w.bucket for w in words.values()}),
        "dictionaryMembership": "PASS",
        "singleBucketInvariant": "PASS",
        "fontCharacterCoverage": "NOT_RUN" if base_font is None else "PASS",
        "missingCharacters": glyph_missing,
    }


def pair_base_score(a: PoolWord, b: PoolWord) -> tuple[int, int, int, int, int]:
    metrics = pair_metrics(a, b)
    both_classified = int(bool(a.semantic_classes and b.semantic_classes))
    return (
        both_classified,
        100 - metrics["translationSimilarity"],
        100 - metrics["lemmaSimilarity"],
        -max(a.rank, b.rank),
        -abs(a.rank - b.rank),
    )


def match_once(
    words: Iterable[PoolWord],
    seed: int,
    forbidden_pairs: set[frozenset[str]],
    rank_band_size: int,
    candidate_scan: int,
    top_choice_window: int,
) -> tuple[list[Pair], list[str]]:
    buckets: dict[str, list[PoolWord]] = defaultdict(list)
    for word in words:
        buckets[word.bucket].append(word)

    pairs: list[Pair] = []
    unmatched: list[str] = []

    for bucket_id, bucket_words in sorted(buckets.items(), key=lambda item: item[0]):
        ordered = sorted(bucket_words, key=lambda w: (w.rank, w.word))
        seeded_order: list[PoolWord] = []
        for i in range(0, len(ordered), rank_band_size):
            block = ordered[i:i + rank_band_size]
            block.sort(key=lambda w: (stable_hash(seed, bucket_id, w.word), w.word))
            seeded_order.extend(block)

        used: set[str] = set()
        n = len(ordered)
        for a in seeded_order:
            if a.word in used:
                continue
            if n < 2:
                used.add(a.word)
                unmatched.append(a.word)
                continue

            start = stable_hash(seed, "start", bucket_id, a.word) % n
            stride = stable_hash(seed, "stride", bucket_id, a.word) % (n - 1) + 1
            while math.gcd(stride, n) != 1:
                stride = (stride + 1) % n or 1

            candidates: list[tuple[tuple[int, int, int, int, int], int, PoolWord]] = []
            index = start
            seen_indexes: set[int] = set()
            for _ in range(min(n - 1, candidate_scan)):
                index = (index + stride) % n
                if index in seen_indexes:
                    break
                seen_indexes.add(index)
                b = ordered[index]
                if b.word == a.word or b.word in used:
                    continue
                logical = frozenset((a.word, b.word))
                if logical in forbidden_pairs or not semantic_pair_ok(a, b):
                    continue
                candidates.append((pair_base_score(a, b), stable_hash(seed, bucket_id, a.word, b.word), b))

            # Small buckets are scanned exhaustively as a deterministic repair pass.
            if not candidates and n <= 1200:
                for b in ordered:
                    if b.word == a.word or b.word in used:
                        continue
                    logical = frozenset((a.word, b.word))
                    if logical in forbidden_pairs or not semantic_pair_ok(a, b):
                        continue
                    candidates.append((pair_base_score(a, b), stable_hash(seed, bucket_id, a.word, b.word), b))

            if not candidates:
                used.add(a.word)
                unmatched.append(a.word)
                continue

            candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
            top = candidates[:min(top_choice_window, len(candidates))]
            selected = top[stable_hash(seed, "pick", bucket_id, a.word) % len(top)][2]
            used.add(a.word)
            used.add(selected.word)
            pairs.append(Pair(a, selected, bucket_id))

        unmatched.extend(w.word for w in ordered if w.word not in used)

    pairs.sort(key=lambda pair: (
        max(pair.source.rank, pair.target.rank),
        min(pair.source.rank, pair.target.rank),
        stable_hash(seed, "output", pair.source.word, pair.target.word),
    ))
    return pairs, sorted(set(unmatched))


def match_variant(
    words: Iterable[PoolWord],
    seed: int,
    target_pairs: int,
    forbidden_pairs: set[frozenset[str]],
    matching_config: dict,
) -> tuple[list[Pair], dict]:
    pool_words = list(words)
    attempts = int(matching_config["attempts"])
    candidates: list[tuple[tuple[int, int, int], list[Pair], list[str], int]] = []
    for attempt in range(attempts):
        attempt_seed = seed + attempt * 1_000_003
        all_pairs, unmatched = match_once(
            pool_words,
            attempt_seed,
            forbidden_pairs,
            int(matching_config["rankBandSize"]),
            int(matching_config["candidateScan"]),
            int(matching_config["topChoiceWindow"]),
        )
        selected = all_pairs[:target_pairs]
        coverage_penalty = sum(max(p.source.rank, p.target.rank) for p in selected)
        quality = (len(all_pairs), -coverage_penalty, -len(unmatched))
        candidates.append((quality, all_pairs, unmatched, attempt_seed))

    quality, all_pairs, unmatched, selected_seed = max(candidates, key=lambda item: item[0])
    if len(all_pairs) < target_pairs:
        raise RuntimeError(
            f"seed {seed}: only {len(all_pairs)} valid pairs found; {target_pairs} required. "
            "Collision policy is repair_then_fail, so the build stops instead of dropping silently."
        )
    selected = all_pairs[:target_pairs]
    return selected, {
        "requestedSeed": seed,
        "selectedAttemptSeed": selected_seed,
        "attempts": attempts,
        "validPairsFound": len(all_pairs),
        "unmatchedCandidateWords": len(unmatched),
        "activeWords": len(selected) * 2,
        "inactivePoolWords": len(pool_words) - len(selected) * 2,
    }


def load_curated_words(path: Path) -> dict[str, CuratedWord]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    return {
        item["word"]: CuratedWord(
            word=item["word"], lemma=item["lemma"], rank=int(item["frequencyRank"]),
            translation=item["translation"], semantic_classes=tuple(item.get("semanticClasses", ())),
        )
        for item in raw["words"]
    }


def build_curated_pairs(config_path: Path, metadata_path: Path, whitelist: set[str]) -> list[Pair]:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    metadata = load_curated_words(metadata_path)
    used: set[str] = set()
    result: list[Pair] = []
    for item in config["pairs"]:
        source, target, bucket = item["source"], item["target"], item["bucket"]
        if source == target or source in used or target in used:
            raise RuntimeError(f"invalid curated pair: {source}/{target}")
        if source not in whitelist or target not in whitelist:
            raise RuntimeError(f"curated word absent from russian.dic: {source}/{target}")
        if source not in metadata or target not in metadata:
            raise RuntimeError(f"missing curated metadata: {source}/{target}")
        sa, ta = metadata[source], metadata[target]
        sw = PoolWord(source, sa.lemma, "FUNCTION/ADV", (bucket,), (bucket,), bucket, sa.rank, sa.translation, (), sa.semantic_classes, ("omega",))
        tw = PoolWord(target, ta.lemma, "FUNCTION/ADV", (bucket,), (bucket,), bucket, ta.rank, ta.translation, (), ta.semantic_classes, ("omega",))
        result.append(Pair(sw, tw, bucket, curated=True))
        used.update((source, target))
    return result


def validate_pairs(name: str, pairs: list[Pair], expected: int, whitelist: set[str]) -> dict:
    errors: list[str] = []
    words = [w for pair in pairs for w in (pair.source.word, pair.target.word)]
    if len(pairs) != expected:
        errors.append(f"logical pair count {len(pairs)} != {expected}")
    if len(words) != len(set(words)):
        errors.append("word reuse inside mapping")
    mapping: dict[str, str] = {}
    bucket_counts: Counter[str] = Counter()
    pos_counts: Counter[str] = Counter()
    for pair in pairs:
        a, b = pair.source, pair.target
        if a.word == b.word:
            errors.append(f"identity mapping {a.word}")
        if a.word not in whitelist or b.word not in whitelist:
            errors.append(f"dictionary membership failure {a.word}/{b.word}")
        if not pair.curated:
            if a.bucket != b.bucket or pair.bucket != a.bucket:
                errors.append(f"bucket mismatch {a.word}/{b.word}")
            if not semantic_pair_ok(a, b):
                errors.append(f"semantic veto failure {a.word}/{b.word}")
        mapping[a.word] = b.word
        mapping[b.word] = a.word
        bucket_counts[pair.bucket] += 1
        pos_counts[a.pos] += 1
    for source, target in mapping.items():
        if mapping.get(target) != source:
            errors.append(f"non-involution {source}->{target}->{mapping.get(target)}")
            break
    if len(mapping) != expected * 2:
        errors.append(f"directed entry count {len(mapping)} != {expected * 2}")
    if errors:
        raise RuntimeError(name + " validation failed:\n" + "\n".join(errors[:100]))
    ranks = [w.rank for pair in pairs for w in (pair.source, pair.target)]
    return {
        "logicalPairs": len(pairs),
        "directedEntries": len(mapping),
        "uniqueWords": len(set(words)),
        "involution": "PASS",
        "identityMappings": 0,
        "wordReuseInsideMapping": 0,
        "semanticVeto": "PASS",
        "exactBucketCompatibility": "PASS",
        "curatedPairs": sum(pair.curated for pair in pairs),
        "contentPairs": sum(not pair.curated for pair in pairs),
        "medianFrequencyRank": sorted(ranks)[len(ranks) // 2],
        "top10000SharePct": round(100 * sum(rank <= 10000 for rank in ranks) / len(ranks), 3),
        "top20000SharePct": round(100 * sum(rank <= 20000 for rank in ranks) / len(ranks), 3),
        "posCounts": dict(pos_counts),
        "usedBucketCount": len(bucket_counts),
    }


def write_variant(
    output_dir: Path,
    name: str,
    pairs: list[Pair],
    variant_config: dict,
    pool_sha: str,
    pool_meta: dict,
    build_info: dict,
    validation: dict,
    base_font: Path | None,
) -> None:
    mapping_meta = {
        "name": "shieldfont-russian",
        "lang": "ru",
        "mapping": "ru-v2",
        "variant": name,
        "version": "2.0.0",
        "mappingId": f"shieldfont-ru-v2-{name}@2.0.0",
        "pairs": len(pairs) * 2,
        "logicalPairs": len(pairs),
        "seed": int(variant_config["seed"]),
        "buildMode": variant_config["mode"],
        "candidatePoolId": pool_meta["poolId"],
        "candidatePoolWords": pool_meta["wordCount"],
        "candidatePoolSha256": pool_sha,
        "activeWords": len(pairs) * 2,
        "collisionPolicy": "repair_then_fail",
        "pairReuseAcrossFamily": "forbidden",
        "font": f"shieldfont-ru-{name}.woff2",
        "family": "ShieldFont RU",
        "fontAuditStatus": "NOT_RUN_NO_BASE_FONT" if base_font is None else "CHARACTER_COVERAGE_PASS_FULL_GSUB_AUDIT_REQUIRED_AFTER_FONT_BUILD",
        "generatorVersion": GENERATOR_VERSION,
        "matching": build_info,
    }
    flat: dict[str, object] = {"_meta": mapping_meta}
    directed: dict[str, str] = {}
    for pair in pairs:
        directed[pair.source.word] = pair.target.word
        directed[pair.target.word] = pair.source.word
    for source in sorted(directed):
        flat[source] = directed[source]

    mapping_path = output_dir / "mappings" / f"{name}.json"
    mapping_path.write_text(json.dumps(flat, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    with (output_dir / "pairs" / f"{name}.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["source", "target", "bucket", "curated"])
        writer.writerows((p.source.word, p.target.word, p.bucket, int(p.curated)) for p in pairs)

    fields = [
        "source", "target", "source_lemma", "target_lemma", "pos", "bucket", "morph_signature",
        "grammar_class", "source_rank", "target_rank", "source_translation", "target_translation",
        "translation_similarity", "lemma_similarity", "semantic_token_overlap", "semantic_class_overlap",
        "source_semantic_classes", "target_semantic_classes", "source_variants", "target_variants", "curated",
    ]
    with (output_dir / "audit" / f"{name}_audit.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for pair in pairs:
            a, b = pair.source, pair.target
            metrics = pair_metrics(a, b) if not pair.curated else {
                "translationSimilarity": "", "lemmaSimilarity": "", "semanticTokenOverlap": "", "semanticClassOverlap": ""
            }
            writer.writerow({
                "source": a.word, "target": b.word, "source_lemma": a.lemma, "target_lemma": b.lemma,
                "pos": a.pos, "bucket": pair.bucket,
                "morph_signature": json.dumps(a.morph_signature, ensure_ascii=False, separators=(",", ":")),
                "grammar_class": json.dumps(a.grammar_class, ensure_ascii=False, separators=(",", ":")),
                "source_rank": a.rank, "target_rank": b.rank,
                "source_translation": a.translation, "target_translation": b.translation,
                "translation_similarity": metrics["translationSimilarity"],
                "lemma_similarity": metrics["lemmaSimilarity"],
                "semantic_token_overlap": metrics["semanticTokenOverlap"],
                "semantic_class_overlap": metrics["semanticClassOverlap"],
                "source_semantic_classes": "|".join(a.semantic_classes),
                "target_semantic_classes": "|".join(b.semantic_classes),
                "source_variants": "|".join(a.source_variants), "target_variants": "|".join(b.source_variants),
                "curated": int(pair.curated),
            })

    (output_dir / "stats" / f"{name}.json").write_text(
        json.dumps({"_meta": mapping_meta, "validation": validation}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Build deterministic Russian mapping family from one canonical bucketed pool.")
    parser.add_argument("--pool", type=Path, required=True)
    parser.add_argument("--dictionary", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--omega-curated", type=Path, required=True)
    parser.add_argument("--omega-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--base-font", type=Path)
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    words, pool_meta = load_pool(args.pool)
    whitelist = load_whitelist(args.dictionary)
    pool_validation = validate_pool(words, whitelist, args.base_font)
    pool_sha = sha256(args.pool)

    output_dir = args.output_dir.resolve()
    for subdir in ("mappings", "pairs", "audit", "stats"):
        (output_dir / subdir).mkdir(parents=True, exist_ok=True)

    family_pairs: dict[str, list[Pair]] = {}
    family_stats: dict[str, dict] = {}
    forbidden_pairs: set[frozenset[str]] = set()

    for name in ("alpha", "beta", "gamma"):
        variant = config["variants"][name]
        pairs, build_info = match_variant(
            words.values(), int(variant["seed"]), int(variant["logicalPairs"]),
            forbidden_pairs, config["matching"],
        )
        validation = validate_pairs(name, pairs, int(variant["logicalPairs"]), whitelist)
        pair_set = {frozenset((p.source.word, p.target.word)) for p in pairs}
        if pair_set & forbidden_pairs:
            raise RuntimeError(f"{name}: exact pair reuse detected")
        forbidden_pairs |= pair_set
        family_pairs[name] = pairs
        family_stats[name] = {"build": build_info, "validation": validation}
        write_variant(output_dir, name, pairs, variant, pool_sha, pool_meta, build_info, validation, args.base_font)

    omega_variant = config["variants"]["omega"]
    curated = build_curated_pairs(args.omega_curated, args.omega_metadata, whitelist)
    curated_words = {w for pair in curated for w in (pair.source.word, pair.target.word)}
    content_target = int(omega_variant["logicalPairs"]) - len(curated)
    content_pool = [
        word for word in words.values()
        if word.rank <= int(omega_variant["contentMaxRank"]) and word.word not in curated_words
    ]
    content_pairs, omega_build = match_variant(
        content_pool, int(omega_variant["seed"]), content_target, forbidden_pairs, config["matching"],
    )
    omega_pairs = curated + content_pairs
    omega_pairs.sort(key=lambda pair: (
        not pair.curated, max(pair.source.rank, pair.target.rank), min(pair.source.rank, pair.target.rank),
        pair.source.word, pair.target.word,
    ))
    omega_validation = validate_pairs("omega", omega_pairs, int(omega_variant["logicalPairs"]), whitelist)
    omega_set = {frozenset((p.source.word, p.target.word)) for p in omega_pairs}
    if omega_set & forbidden_pairs:
        raise RuntimeError("omega: exact pair reuse detected")
    family_pairs["omega"] = omega_pairs
    family_stats["omega"] = {"build": omega_build, "validation": omega_validation}
    write_variant(output_dir, "omega", omega_pairs, omega_variant, pool_sha, pool_meta, omega_build, omega_validation, args.base_font)

    cross: dict[str, dict] = {}
    names = list(family_pairs)
    for i, left in enumerate(names):
        left_pairs = {frozenset((p.source.word, p.target.word)) for p in family_pairs[left]}
        left_words = {w for p in family_pairs[left] for w in (p.source.word, p.target.word)}
        for right in names[i + 1:]:
            right_pairs = {frozenset((p.source.word, p.target.word)) for p in family_pairs[right]}
            right_words = {w for p in family_pairs[right] for w in (p.source.word, p.target.word)}
            cross[f"{left}__{right}"] = {
                "exactLogicalPairOverlap": len(left_pairs & right_pairs),
                "wordOverlap": len(left_words & right_words),
                "wordJaccard": round(len(left_words & right_words) / len(left_words | right_words), 6),
            }

    manifest = {
        "schema": 2,
        "generatorVersion": GENERATOR_VERSION,
        "language": "ru",
        "normalization": "Unicode NFC lowercase",
        "dictionarySha256": sha256(args.dictionary),
        "candidatePool": {"id": pool_meta["poolId"], "sha256": pool_sha, **pool_validation},
        "configSha256": sha256(args.config),
        "variants": family_stats,
        "crossVariantChecks": cross,
        "fontAudit": "NOT_RUN_NO_BASE_FONT" if args.base_font is None else "CHARACTER_COVERAGE_PASS; FULL GSUB/HARFBUZZ AUDIT MUST FOLLOW FONT GENERATION",
        "files": {},
    }
    for path in sorted(output_dir.rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            manifest["files"][str(path.relative_to(output_dir))] = {"bytes": path.stat().st_size, "sha256": sha256(path)}
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print(json.dumps({
        "output": str(output_dir), "pool": pool_validation,
        "variants": {name: stats["validation"] for name, stats in family_stats.items()},
        "cross": cross,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
