# Russian mapping generator v2

Этот пакет содержит перестроенный воспроизводимый генератор и заново созданные наборы `alpha`, `beta`, `gamma`, `omega`.

## Основные изменения

1. `alpha`, `beta` и `gamma` строятся из одного канонического пула:
   - 14 764 содержательные словоформы;
   - 167 точных грамматических корзин;
   - каждая словоформа закреплена ровно за одной корзиной.
2. `alpha` создаётся в режиме полного build.
3. `beta` и `gamma` создаются как `reseed-vetoed`:
   - тот же pool;
   - те же определения корзин;
   - другой seed;
   - повторный семантический veto после перепаривания.
4. Конфликты не удаляются молча. Политика: `repair_then_fail`.
5. Точные логические пары не повторяются между вариантами.
6. `omega` содержит 41 фиксированную частотную пару служебных слов/наречий с отдельными функциональными корзинами и 1 226 содержательных пар.
7. Каждый mapping содержит `_meta`, `mappingId`, seed, режим построения, SHA-256 пула и сведения о воспроизводимости.
8. Сохраняются:
   - плоский двунаправленный JSON;
   - CSV логических пар;
   - подробный audit CSV;
   - stats и manifest с SHA-256.

## Результаты

| Набор | Логических пар | Направленных записей | Режим |
|---|---:|---:|---|
| alpha | 5 985 | 11 970 | build |
| beta | 6 017 | 12 034 | reseed-vetoed |
| gamma | 6 018 | 12 036 | reseed-vetoed |
| omega | 1 267 | 2 534 | coverage-build |

Для всех наборов подтверждены:

- точное количество записей;
- `mapping[mapping[word]] == word`;
- отсутствие самозамен;
- отсутствие повторного использования слова внутри mapping;
- наличие каждой формы в исходном `russian.dic`;
- Unicode NFC, нижний регистр, только кириллица;
- совпадение точной грамматической корзины у содержательных пар;
- прохождение semantic veto;
- нулевое пересечение точных логических пар между вариантами.

## Воспроизведение

Требуется Python 3.13 и исходный архив `russian.dic` с SHA-256:

```text
cf8eded45905baa02330b59773d68e2376d3e3a2eaf51aa26478e68b8cef8d5f
```

Установка:

```bash
python -m pip install -r requirements.txt
```

Полная пересборка:

```bash
python reproduce.py \
  --dictionary /path/to/russian.dic.zip \
  --output-dir out \
  --verify-expected
```

`--verify-expected` требует побайтового совпадения всех JSON, CSV и audit-файлов с включёнными эталонными хешами.

## Создание частного reseed

```bash
python tools/reseed_mapping.py \
  --pool pool/ru_family_pool_v2.json \
  --dictionary /path/to/russian.dic.zip \
  --config config/build_config.json \
  --seed 987654321 \
  --logical-pairs 6000 \
  --name private \
  --output-dir private-out \
  --forbid-mapping output/mappings/alpha.json
```

Частный mapping проходит тот же semantic veto и не использует пары из переданных `--forbid-mapping`.

## Bootstrap пула

В пакет уже включён зафиксированный `pool/ru_family_pool_v2.json`. Скрипт `tools/bootstrap_pool.py` позволяет заново получить его из audit-файлов предыдущего build:

```bash
python tools/bootstrap_pool.py --audit-dir previous/audit --out pool/ru_family_pool_v2.json
```

## Проверка

```bash
python tools/validate_family.py \
  --output-dir output \
  --pool pool/ru_family_pool_v2.json \
  --dictionary /path/to/russian.dic.zip \
  --omega-curated config/omega_curated_pairs.json
```

## Базовый шрифт

Параметр `--base-font font.ttf` выполняет проверку покрытия всех строчных и прописных кириллических символов в `cmap`.

В данный пакет базовый шрифт не передавался, поэтому полный GSUB/HarfBuzz-аудит готового шрифта не выполнялся. После генерации шрифта необходимо отдельно проверить lowercase, Capitalized, ALL CAPS, границы text run, короткие слова внутри длинных слов и метрики composite glyphs.
