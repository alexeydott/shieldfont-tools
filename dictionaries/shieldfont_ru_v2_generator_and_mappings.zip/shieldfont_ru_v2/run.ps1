param(
  [Parameter(Mandatory=$true)][string]$Dictionary,
  [string]$OutputDir = "out"
)
python reproduce.py --dictionary $Dictionary --output-dir $OutputDir --verify-expected
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
