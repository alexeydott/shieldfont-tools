#!/usr/bin/env sh
set -eu
python reproduce.py --dictionary "$1" --output-dir "${2:-out}" --verify-expected
